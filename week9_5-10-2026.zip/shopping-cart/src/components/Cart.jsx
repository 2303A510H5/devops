import CartItem from './CartItem.jsx'
import Summary from './Summary.jsx'

export default function Cart({ items, onRemove, onChangeQuantity, onClear, totalItems, subtotal, discount, delivery, total }) {
  return <aside className="cart-panel">
    <div className="cart-heading"><div><span className="eyebrow">YOUR SELECTION</span><h2>Shopping cart <span>{totalItems}</span></h2></div>{items.length > 0 && <button className="clear-button" onClick={onClear}>Clear cart</button>}</div>
    {items.length === 0 ? <div className="empty-cart"><div className="empty-icon">🛒</div><h3>Your cart is empty</h3><p>Looks like you haven't added anything yet. Explore products and find something you love.</p></div> : <>
      <div className="cart-items">{items.map(item => <CartItem key={item.id} item={item} name={item.name} price={item.price} quantity={item.quantity} onRemove={onRemove} onChangeQuantity={onChangeQuantity} />)}</div>
      <Summary totalItems={totalItems} subtotal={subtotal} discount={discount} delivery={delivery} total={total} />
    </>}
    {items.length === 0 && <div className="empty-summary"><span>ITEMS IN CART</span><strong>0</strong></div>}
  </aside>
}
