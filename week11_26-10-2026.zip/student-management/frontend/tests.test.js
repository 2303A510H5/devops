const test = require("node:test");
const assert = require("node:assert/strict");

test("frontend test runner is available for the CI unit-test stage", () => {
  assert.equal(typeof "Student Management", "string");
});
