const express = require('express');
const fs = require('fs');
const path = require('path');

const router = express.Router();
const DATA_FILE = path.join(__dirname, '..', 'data', 'products.json');

function readProducts() {
  return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
}
function writeProducts(products) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(products, null, 2));
}
function validateProduct(body, partial = false) {
  const errors = [];
  const fields = ['name', 'description', 'price', 'category', 'stock'];
  if (!partial) {
    for (const field of fields) {
      if (body[field] === undefined || body[field] === null || body[field] === '') {
        errors.push(`${field} is required`);
      }
    }
  }
  if (body.name !== undefined && (typeof body.name !== 'string' || !body.name.trim())) errors.push('name must be a non-empty string');
  if (body.description !== undefined && typeof body.description !== 'string') errors.push('description must be a string');
  if (body.category !== undefined && (typeof body.category !== 'string' || !body.category.trim())) errors.push('category must be a non-empty string');
  if (body.price !== undefined && (!Number.isFinite(Number(body.price)) || Number(body.price) < 0)) errors.push('price must be a non-negative number');
  if (body.stock !== undefined && (!Number.isInteger(Number(body.stock)) || Number(body.stock) < 0)) errors.push('stock must be a non-negative integer');
  return errors;
}

// GET /products - retrieve all products
router.get('/', (req, res) => {
  res.status(200).json({ success: true, count: readProducts().length, data: readProducts() });
});

// GET /products/:id - retrieve one product
router.get('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ success: false, message: 'Product ID must be a positive integer' });
  const product = readProducts().find(p => p.id === id);
  if (!product) return res.status(404).json({ success: false, message: 'Product not found' });
  res.status(200).json({ success: true, data: product });
});

// POST /products - add a product
router.post('/', (req, res) => {
  const errors = validateProduct(req.body);
  if (errors.length) return res.status(400).json({ success: false, message: 'Validation failed', errors });
  const products = readProducts();
  const product = {
    id: products.length ? Math.max(...products.map(p => p.id)) + 1 : 1,
    name: req.body.name.trim(),
    description: req.body.description,
    price: Number(req.body.price),
    category: req.body.category.trim(),
    stock: Number(req.body.stock)
  };
  products.push(product);
  writeProducts(products);
  res.status(201).json({ success: true, message: 'Product created successfully', data: product });
});

// PUT /products/:id - update product
router.put('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ success: false, message: 'Product ID must be a positive integer' });
  const products = readProducts();
  const index = products.findIndex(p => p.id === id);
  if (index === -1) return res.status(404).json({ success: false, message: 'Product not found' });
  const errors = validateProduct(req.body, true);
  if (errors.length) return res.status(400).json({ success: false, message: 'Validation failed', errors });
  const allowed = ['name', 'description', 'price', 'category', 'stock'];
  for (const field of allowed) {
    if (req.body[field] !== undefined) {
      products[index][field] = ['price', 'stock'].includes(field) ? Number(req.body[field]) : req.body[field].trim?.() ?? req.body[field];
    }
  }
  writeProducts(products);
  res.status(200).json({ success: true, message: 'Product updated successfully', data: products[index] });
});

// DELETE /products/:id - delete product
router.delete('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ success: false, message: 'Product ID must be a positive integer' });
  const products = readProducts();
  const index = products.findIndex(p => p.id === id);
  if (index === -1) return res.status(404).json({ success: false, message: 'Product not found' });
  const deleted = products.splice(index, 1)[0];
  writeProducts(products);
  res.status(200).json({ success: true, message: 'Product deleted successfully', data: deleted });
});

module.exports = router;
