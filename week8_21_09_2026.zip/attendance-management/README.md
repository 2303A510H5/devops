# Student Attendance Management System

A responsive React dashboard demonstrating props and state management with `useState()`.

## Features
- Student directory with name, roll number, branch and attendance percentage
- Reusable `Header`, `StudentList`, `StudentCard`, `Attendance` and `Summary` components
- Mark each student Present or Absent
- Attendance percentage updates dynamically from the initial percentage
- Live present, absent and total student statistics
- Eligible (75% or above) and Not Eligible (below 75%) status
- Highlights students below 75% attendance
- Search by student name, roll number or branch
- Reset Attendance restores the original sample records
- Responsive dashboard layout

## Run locally
Install Node.js 18+ and open this folder in VS Code. In the terminal run:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually http://localhost:5173).

## How attendance works
The parent `App` component stores student records in React state and passes student information and event handlers to child components through props. Each Present/Absent action updates the selected student's attendance percentage and today's status. The dashboard statistics are derived from the current state, so they update immediately.

For the demonstration, the sample attendance percentage changes by one percentage point when a student is marked Present or Absent. Reset Attendance restores the original sample percentages and clears today's status.
