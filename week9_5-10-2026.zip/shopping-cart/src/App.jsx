import { useMemo, useState } from 'react'
import Header from './components/Header.jsx'
import ProductList from './components/ProductList.jsx'
import Cart from './components/Cart.jsx'
import { products } from './data.js'

export default function App() {
  const [cart, setCart] = useState([])
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('All')

  const addToCart = (product) => {
    setCart(current => {
      const existing = current.find(item => item.id === product.id)
      if (existing) return current.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)
      return [...current, { ...product, quantity: 1 }]
    })
  }

  const removeFromCart = (id) => setCart(current => current.filter(item => item.id !== id))
  const changeQuantity = (id, amount) => {
    setCart(current => current.map(item => item.id === id ? { ...item, quantity: Math.max(1, item.quantity + amount) } : item))
  }
  const clearCart = () => setCart([])

  const filteredProducts = useMemo(() => products.filter(product => {
    const matchesSearch = `${product.name} ${product.id} ${product.category}`.toLowerCase().includes(search.toLowerCase())
    return matchesSearch && (category === 'All' || product.category === category)
  }), [search, category])

  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0)
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const discount = subtotal > 5000 ? subtotal * 0.10 : 0
  const delivery = subtotal === 0 || subtotal > 2000 ? 0 : 50
  const total = subtotal - discount + delivery

  return (
    <div className="app-shell">
      <Header itemCount={totalItems} />
      <main className="container">
        <section className="welcome">
          <div><span className="eyebrow">YOUR EVERYDAY FINDS</span><h1>Online Shopping <span>Cart</span></h1><p>Discover products you love and make every purchase count.</p></div>
          <div className="welcome-art" aria-hidden="true"><span>🛍️</span><i>✦</i><b>GOOD CHOICES<br />GOOD DAYS</b></div>
        </section>
        <div className="content-grid">
          <ProductList products={filteredProducts} search={search} onSearch={setSearch} category={category} onCategory={setCategory} onAdd={addToCart} />
          <Cart items={cart} onRemove={removeFromCart} onChangeQuantity={changeQuantity} onClear={clearCart} totalItems={totalItems} subtotal={subtotal} discount={discount} delivery={delivery} total={total} />
        </div>
      </main>
      <footer className="footer">© 2026 Online Shopping Cart <span>Made for a smarter shopping experience</span></footer>
    </div>
  )
}
