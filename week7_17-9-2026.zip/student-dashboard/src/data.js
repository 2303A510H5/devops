export const students = [
  {
    id: 1, name: 'Rahul Sharma', rollNo: 'CSE101', branch: 'Computer Science', shortBranch: 'CSE',
    year: 'III Year', semester: 'Semester 5', email: 'rahul.sharma@college.edu', phone: '+91 98765 43210',
    attendance: 86, cgpa: '8.6', avatar: 'RS',
    subjects: [
      { code: 'CS501', name: 'Design and Analysis of Algorithms', faculty: 'Dr. Meera Rao', credits: 4, score: 88 },
      { code: 'CS502', name: 'Database Management Systems', faculty: 'Prof. K. Prasad', credits: 4, score: 92 },
      { code: 'CS503', name: 'Computer Networks', faculty: 'Dr. Anita Das', credits: 3, score: 81 },
      { code: 'CS504', name: 'Operating Systems', faculty: 'Prof. S. Kumar', credits: 3, score: 85 }
    ],
    exams: [
      { subject: 'Design and Analysis of Algorithms', date: '18 Nov 2026', time: '10:00 AM – 1:00 PM', venue: 'Block A · Room 204', status: 'Upcoming' },
      { subject: 'Database Management Systems', date: '21 Nov 2026', time: '10:00 AM – 1:00 PM', venue: 'Block B · Room 108', status: 'Upcoming' },
      { subject: 'Computer Networks', date: '24 Nov 2026', time: '2:00 PM – 5:00 PM', venue: 'Block A · Room 105', status: 'Upcoming' }
    ]
  },
  {
    id: 2, name: 'Priya Reddy', rollNo: 'ECE102', branch: 'Electronics and Communication', shortBranch: 'ECE',
    year: 'II Year', semester: 'Semester 3', email: 'priya.reddy@college.edu', phone: '+91 98765 12345',
    attendance: 72, cgpa: '9.1', avatar: 'PR',
    subjects: [
      { code: 'EC301', name: 'Signals and Systems', faculty: 'Dr. P. Nair', credits: 4, score: 91 },
      { code: 'EC302', name: 'Digital Electronics', faculty: 'Prof. A. Reddy', credits: 4, score: 89 },
      { code: 'EC303', name: 'Electronic Devices', faculty: 'Dr. S. Iyer', credits: 3, score: 86 }
    ],
    exams: [
      { subject: 'Signals and Systems', date: '19 Nov 2026', time: '10:00 AM – 1:00 PM', venue: 'Block C · Room 302', status: 'Upcoming' },
      { subject: 'Digital Electronics', date: '22 Nov 2026', time: '2:00 PM – 5:00 PM', venue: 'Block C · Room 210', status: 'Upcoming' }
    ]
  },
  {
    id: 3, name: 'Arjun Kumar', rollNo: 'IT103', branch: 'Information Technology', shortBranch: 'IT',
    year: 'IV Year', semester: 'Semester 7', email: 'arjun.kumar@college.edu', phone: '+91 91234 56789',
    attendance: 94, cgpa: '8.8', avatar: 'AK',
    subjects: [
      { code: 'IT701', name: 'Cloud Computing', faculty: 'Prof. V. Ramesh', credits: 4, score: 90 },
      { code: 'IT702', name: 'Machine Learning', faculty: 'Dr. S. Bose', credits: 4, score: 94 },
      { code: 'IT703', name: 'Cyber Security', faculty: 'Prof. N. Shah', credits: 3, score: 87 },
      { code: 'IT704', name: 'Software Project Management', faculty: 'Dr. L. Joseph', credits: 3, score: 89 }
    ],
    exams: [
      { subject: 'Cloud Computing', date: '20 Nov 2026', time: '10:00 AM – 1:00 PM', venue: 'Block D · Lab 1', status: 'Upcoming' },
      { subject: 'Machine Learning', date: '25 Nov 2026', time: '10:00 AM – 1:00 PM', venue: 'Block D · Room 401', status: 'Upcoming' }
    ]
  }
]
