export default function Attendance({ status, onPresent, onAbsent }) {
  return <div className="attendance-actions">
    <button className={`mark-button present ${status === 'Present' ? 'selected' : ''}`} onClick={onPresent} aria-pressed={status === 'Present'}>✓ Present</button>
    <button className={`mark-button absent ${status === 'Absent' ? 'selected' : ''}`} onClick={onAbsent} aria-pressed={status === 'Absent'}>× Absent</button>
    {status && <small className={`marked-label ${status.toLowerCase()}`}>Marked {status}</small>}
  </div>
}
