const app = require("./app");
const { initializeDatabase } = require("./db");

const PORT = Number(process.env.PORT) || 5000;

initializeDatabase()
  .then(() => {
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Student Management API listening on port ${PORT}`);
    });
  })
  .catch(error => {
    console.error("Unable to initialize database:", error);
    process.exit(1);
  });
