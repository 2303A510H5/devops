import StudentCard from './StudentCard.jsx'

export default function StudentList({ students, onMarkAttendance }) {
  if (students.length === 0) return <div className="empty-state"><span>⌕</span><h3>No students found</h3><p>Try a different name, roll number or branch.</p></div>
  return <div className="student-list">
    <div className="table-header"><span>STUDENT</span><span>ROLL NUMBER</span><span>BRANCH</span><span>ATTENDANCE</span><span>ELIGIBILITY</span><span>MARK TODAY</span></div>
    {students.map(student => <StudentCard key={student.id} student={student} name={student.name} rollNo={student.rollNo} onMarkAttendance={onMarkAttendance} />)}
  </div>
}
