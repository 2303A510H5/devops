function SummaryCard({ label, value, note, icon, tone }) {
  return <article className="summary-card"><div className="summary-top"><span>{label}</span><span className={`summary-icon ${tone}`}>{icon}</span></div><strong>{value}</strong><small>{note}</small></article>
}

export default function Summary({ total, present, absent, pending, average, eligible }) {
  return <section className="summary-grid">
    <SummaryCard label="Total Students" value={total} note="Registered in this class" icon="♙" tone="purple" />
    <SummaryCard label="Present Today" value={present} note="Marked as present" icon="✓" tone="green" />
    <SummaryCard label="Absent Today" value={absent} note="Marked as absent" icon="×" tone="red" />
    <SummaryCard label="Class Average" value={`${average}%`} note={`${eligible} students eligible`} icon="▥" tone="blue" />
  </section>
}
