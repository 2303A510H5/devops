const js = require("@eslint/js");

module.exports = [
  js.configs.recommended,
  {
    files: ["**/*.js"],
    languageOptions: {
      ecmaVersion: "latest",
      sourceType: "commonjs",
      globals: { require: "readonly", module: "readonly", process: "readonly", console: "readonly", describe: "readonly", test: "readonly", expect: "readonly", beforeEach: "readonly" }
    },
    rules: { "no-unused-vars": ["error", { argsIgnorePattern: "^_" }] }
  }
];
