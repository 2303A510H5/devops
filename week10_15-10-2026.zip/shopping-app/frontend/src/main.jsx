import React from "react";
import { createRoot } from "react-dom/client";
import { ShoppingApp } from "./components/ShoppingApp";
import "./style.css";

createRoot(document.getElementById("root")).render(
  <React.StrictMode><ShoppingApp /></React.StrictMode>
);
