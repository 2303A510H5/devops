# Library Management System

A small JavaScript project demonstrating a collaborative Git workflow with separate book and member management modules.

## Project structure

```text
library-management-system/
├── books.js
├── members.js
├── index.js
├── package.json
├── .gitignore
└── README.md
```

## Modules
- `books.js`: add, update, search and remove books.
- `members.js`: register, update, search and remove library members.
- `index.js`: demonstrates both modules with sample records.

## Run locally
```bash
npm install
npm start
```

## Git workflow

### 1. Configure Git
```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```

### 2. Initialize repository and connect GitHub
Create an empty GitHub repository named `library-management-system` (do not initialize it with a README if you plan to push this existing project).

From this project folder:
```bash
git init
git add .
git commit -m "chore: initialize library management system"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/library-management-system.git
git push -u origin main
```
Replace `YOUR_USERNAME` with your GitHub username.

### 3. Create feature branches
```bash
git switch -c feature-books
```
The `books.js` module is already included. Commit it on the feature branch:
```bash
git add books.js
git commit -m "feat: add book management module"
git push -u origin feature-books
```

Create the members branch from main:
```bash
git switch main
git switch -c feature-members
```
Commit the member module:
```bash
git add members.js
git commit -m "feat: add library member management module"
git push -u origin feature-members
```

### 4. Merge feature branches into main
```bash
git switch main
git merge --no-ff feature-books -m "merge: integrate book management"
git merge --no-ff feature-members -m "merge: integrate member management"
git push origin main
```
If Git reports a conflict, open each conflicted file, choose the correct combined content, remove conflict markers (`<<<<<<<`, `=======`, `>>>>>>>`), then:
```bash
git add <resolved-file>
git commit
```
No merge conflict is expected in this starter workflow because the two feature branches add separate module files.

### 5. Create release tag
```bash
git tag -a v1.0-library -m "Library Management System version 1.0"
git push origin v1.0-library
```

### 6. Verify branches and history
```bash
git branch -a
git log --oneline --graph --decorate --all
git tag
```

## Notes
- GitHub authentication may require a browser sign-in or a Personal Access Token instead of your account password, depending on your Git setup.
- This project uses in-memory arrays for demonstration. Data resets when the Node.js process restarts; it is intended to demonstrate module logic and Git operations, not persistent storage.
