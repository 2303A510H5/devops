import { Link } from 'react-router-dom'

export default function BookCard({ book, onAdd }) {
  return <article className="book-card">
    <Link to={`/books/${book.id}`} className={`book-cover ${book.color}`} aria-label={`View ${book.title} details`}>
      <span className="cover-brand">THE READING ROOM</span><span className="cover-art">{book.cover}</span><strong>{book.title}</strong><small>{book.author}</small><i>✦</i>
    </Link>
    <div className="book-info"><span className="book-category">{book.category}</span><Link to={`/books/${book.id}`} className="book-title">{book.title}</Link><p>{book.author}</p><div className="book-bottom"><strong>₹{book.price.toLocaleString('en-IN')}</strong><button onClick={() => onAdd(book)} className="add-button">＋ Add</button></div></div>
  </article>
}
