import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { students } from '../data.js'

export default function StudentDetails() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [student, setStudent] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    console.log(`StudentDetails: Loading student ${id}`)
    setLoading(true)
    setError('')
    setStudent(null)
    const timer = setTimeout(() => {
      const record = students.find(item => item.id === id)
      if (record) setStudent(record)
      else setError(`Student with ID ${id} does not exist.`)
      setLoading(false)
    }, 450)
    return () => {
      clearTimeout(timer)
      console.log(`StudentDetails: Cleanup for student ${id}`)
    }
  }, [id])

  return (
    <>
      <button className="back-button" onClick={() => navigate(-1)}>← Back</button>
      <div className="page-title-row"><div><span className="eyebrow">STUDENT PROFILE</span><h1>Student Details</h1><p className="muted">Detailed academic information for the selected student.</p></div></div>
      {loading && <div className="panel loading-state"><span className="spinner"></span><p>Loading student information...</p></div>}
      {!loading && error && <div className="panel error-state"><span>!</span><h2>Student not found</h2><p>{error}</p><Link className="btn btn-primary" to="/students">Return to Students</Link></div>}
      {!loading && student && <section className="panel profile-panel"><div className="profile-header"><span className="profile-avatar">{student.name.charAt(0)}</span><div><span className="status"><i></i>{student.status}</span><h2>{student.name}</h2><p>Student ID: {student.id}</p></div></div><div className="detail-grid"><div><small>STUDENT ID</small><strong>{student.id}</strong></div><div><small>FULL NAME</small><strong>{student.name}</strong></div><div><small>BRANCH</small><strong>{student.branch}</strong></div><div><small>YEAR</small><strong>{student.year}</strong></div><div><small>EMAIL ADDRESS</small><strong>{student.email}</strong></div><div><small>CGPA</small><strong>{student.cgpa} / 10</strong></div></div><Link className="btn btn-primary" to="/students">← Back to student list</Link></section>}
    </>
  )
}
