const express = require("express");
const cors = require("cors");
const db = require("./db");

const app = express();
app.use(cors());
app.use(express.json());

function validateStudent(body) {
  return body &&
    typeof body.name === "string" && body.name.trim() &&
    typeof body.rollNo === "string" && body.rollNo.trim() &&
    typeof body.branch === "string" && body.branch.trim();
}

app.get("/health", async (_req, res) => {
  try {
    if (db.pool) await db.pool.query("SELECT 1");
    res.json({ status: "UP", database: db.pool ? "connected" : "in-memory-demo" });
  } catch {
    res.status(503).json({ status: "DOWN", database: "disconnected" });
  }
});

app.get("/api/students", async (_req, res, next) => {
  try {
    res.json(await db.listStudents());
  } catch (error) { next(error); }
});

app.get("/api/students/:id", async (req, res, next) => {
  try {
    const student = await db.getStudent(Number(req.params.id));
    if (!student) return res.status(404).json({ error: "Student not found" });
    res.json(student);
  } catch (error) { next(error); }
});

app.post("/api/students", async (req, res, next) => {
  try {
    if (!validateStudent(req.body)) {
      return res.status(400).json({ error: "name, rollNo, and branch are required" });
    }
    const student = await db.createStudent({
      name: req.body.name.trim(),
      rollNo: req.body.rollNo.trim(),
      branch: req.body.branch.trim()
    });
    res.status(201).json(student);
  } catch (error) {
    if (error.code === "23505") {
      return res.status(409).json({ error: "rollNo already exists" });
    }
    next(error);
  }
});

app.put("/api/students/:id", async (req, res, next) => {
  try {
    if (!validateStudent(req.body)) {
      return res.status(400).json({ error: "name, rollNo, and branch are required" });
    }
    const student = await db.updateStudent(Number(req.params.id), {
      name: req.body.name.trim(),
      rollNo: req.body.rollNo.trim(),
      branch: req.body.branch.trim()
    });
    if (!student) return res.status(404).json({ error: "Student not found" });
    res.json(student);
  } catch (error) {
    if (error.code === "23505") {
      return res.status(409).json({ error: "rollNo already exists" });
    }
    next(error);
  }
});

app.delete("/api/students/:id", async (req, res, next) => {
  try {
    const deleted = await db.deleteStudent(Number(req.params.id));
    if (!deleted) return res.status(404).json({ error: "Student not found" });
    res.json({ message: "Student deleted successfully" });
  } catch (error) { next(error); }
});

app.use((req, res) => {
  res.status(404).json({ error: "Route not found", path: req.originalUrl });
});

app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(500).json({ error: "Internal server error" });
});

module.exports = app;
