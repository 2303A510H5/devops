import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { books } from '../data.js'

export default function BookDetails({ onAdd }) {
  const { id } = useParams()
  const navigate = useNavigate()
  const [book, setBook] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    console.log(`BookDetails: loading book ${id}`)
    setLoading(true)
    setBook(null)
    const timer = setTimeout(() => {
      setBook(books.find(item => item.id === id) || null)
      setLoading(false)
    }, 500)
    return () => {
      clearTimeout(timer)
      console.log(`BookDetails: cleanup for book ${id}`)
    }
  }, [id])

  return <>
    <button className="back-button" onClick={() => navigate(-1)}>← Go Back</button>
    {loading && <div className="loading-panel"><span className="spinner"></span><p>Loading book details...</p></div>}
    {!loading && !book && <div className="not-found-book"><span>⌕</span><h1>Book Not Found</h1><p>Sorry, we couldn't find a book with ID <strong>{id}</strong>.</p><Link to="/books" className="primary-button">Browse all books</Link></div>}
    {!loading && book && <section className="detail-layout"><div className={`detail-cover book-cover ${book.color}`}><span className="cover-brand">THE READING ROOM</span><span className="cover-art">{book.cover}</span><strong>{book.title}</strong><small>{book.author}</small><i>✦</i></div><div className="detail-copy"><span className="eyebrow">BOOK DETAILS · #{book.id}</span><span className="book-category">{book.category}</span><h1>{book.title}</h1><p className="detail-author">by {book.author}</p><div className="rating">★★★★★ <span>{book.rating} reader rating</span></div><p className="detail-description">{book.description}</p><div className="book-facts"><div><small>PAGES</small><strong>{book.pages}</strong></div><div><small>FIRST PUBLISHED</small><strong>{book.year}</strong></div><div><small>BOOK ID</small><strong>{book.id}</strong></div></div><div className="detail-buy"><strong>₹{book.price.toLocaleString('en-IN')}</strong><button className="primary-button" onClick={() => onAdd(book)}>＋ Add to Cart</button></div><Link to="/cart" className="text-link cart-shortcut">View your cart →</Link></div></section>}
  </>
}
