// Book management module
class BookManager {
  constructor(initialBooks = []) {
    this.books = initialBooks.map(book => ({ ...book }));
    this.nextId = this.books.reduce((max, book) => Math.max(max, book.id || 0), 0) + 1;
  }

  addBook({ title, author, isbn, year }) {
    if (!title || !author || !isbn) {
      throw new Error('Title, author, and ISBN are required');
    }
    if (this.books.some(book => book.isbn === isbn)) {
      throw new Error('A book with this ISBN already exists');
    }
    const book = { id: this.nextId++, title: title.trim(), author: author.trim(), isbn: isbn.trim(), year: year ?? null };
    this.books.push(book);
    return { ...book };
  }

  updateBook(id, updates) {
    const book = this.books.find(item => item.id === Number(id));
    if (!book) return null;
    if (updates.isbn && this.books.some(item => item.id !== book.id && item.isbn === updates.isbn)) {
      throw new Error('A book with this ISBN already exists');
    }
    const allowed = ['title', 'author', 'isbn', 'year'];
    for (const key of allowed) {
      if (updates[key] !== undefined) book[key] = typeof updates[key] === 'string' ? updates[key].trim() : updates[key];
    }
    return { ...book };
  }

  searchBooks(query) {
    const term = String(query || '').toLowerCase();
    return this.books
      .filter(book => [book.title, book.author, book.isbn].some(value => String(value).toLowerCase().includes(term)))
      .map(book => ({ ...book }));
  }

  removeBook(id) {
    const index = this.books.findIndex(book => book.id === Number(id));
    if (index === -1) return null;
    return this.books.splice(index, 1)[0];
  }

  getAllBooks() {
    return this.books.map(book => ({ ...book }));
  }
}

module.exports = BookManager;
