import React from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

function App() {
  return (
    <main>
      <h1>Online Shopping Application</h1>
      <p>Product, cart, and order integration test demo.</p>
      <p>Backend API: <code>http://localhost:5000/api/products</code></p>
    </main>
  );
}

createRoot(document.getElementById("root")).render(<App />);
