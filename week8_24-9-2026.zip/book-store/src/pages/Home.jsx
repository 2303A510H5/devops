import { Link } from 'react-router-dom'
import { books } from '../data.js'
import BookCard from '../components/BookCard.jsx'

export default function Home({ onAdd }) {
  return <>
    <section className="hero"><div className="hero-copy"><span className="eyebrow">A WORLD BETWEEN THE PAGES</span><h1>Find your next<br /><em>great read.</em></h1><p>Stories that stay with you. Ideas that move you. Discover books for every mood and every moment.</p><Link to="/books" className="primary-button">Explore the collection <span>→</span></Link></div><div className="hero-visual" aria-hidden="true"><div className="hero-book book-one"><span>THE<br/>ALCHEMIST</span><small>PAULO COELHO</small></div><div className="hero-book book-two"><span>ATOMIC<br/>HABITS</span><small>JAMES CLEAR</small></div><div className="hero-book book-three"><span>WINGS<br/>OF FIRE</span><small>A. P. J. ABDUL KALAM</small></div><span className="sparkle sparkle-one">✳</span><span className="sparkle sparkle-two">✦</span></div></section>
    <section className="section-head"><div><span className="eyebrow">A FEW READER FAVOURITES</span><h2>Books worth turning pages for</h2></div><Link to="/books" className="text-link">View all books →</Link></section>
    <div className="book-grid home-grid">{books.slice(0, 3).map(book => <BookCard key={book.id} book={book} onAdd={onAdd} />)}</div>
    <section className="quote-strip"><span>“</span><p>A book is a dream that you hold in your hands.</p><small>— Neil Gaiman</small></section>
  </>
}
