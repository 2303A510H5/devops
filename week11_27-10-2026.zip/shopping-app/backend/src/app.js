const express = require("express");
const cors = require("cors");
const { pool } = require("./db");
const { calculateTotal } = require("./helpers");

const app = express();
app.use(cors());
app.use(express.json());

const demoProducts = [
  { id: 101, name: "Laptop", price: 60000 },
  { id: 102, name: "Headphones", price: 2000 }
];
const demoCart = [];
const demoOrders = [];
let nextOrderId = 1;

async function queryOrDemo(sql, params, demoFn) {
  if (pool) return pool.query(sql, params);
  return demoFn();
}

app.get("/health", async (_req, res) => {
  try {
    if (pool) await pool.query("SELECT 1");
    res.json({ status: "UP", database: pool ? "connected" : "demo-memory" });
  } catch {
    res.status(503).json({ status: "DOWN", database: "disconnected" });
  }
});

app.get("/api/products", async (_req, res, next) => {
  try {
    const result = await queryOrDemo(
      "SELECT id, name, price FROM products ORDER BY id", [],
      () => ({ rows: demoProducts })
    );
    res.json(result.rows);
  } catch (err) { next(err); }
});

app.get("/api/products/:id", async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const result = await queryOrDemo(
      "SELECT id, name, price FROM products WHERE id = $1", [id],
      () => ({ rows: demoProducts.filter(p => p.id === id) })
    );
    if (!result.rows.length) return res.status(404).json({ error: "Product not found" });
    res.json(result.rows[0]);
  } catch (err) { next(err); }
});

app.post("/api/cart", async (req, res, next) => {
  try {
    const productId = Number(req.body.productId);
    const quantity = Number(req.body.quantity);
    if (!Number.isInteger(quantity) || quantity < 1) {
      return res.status(400).json({ error: "quantity must be a positive integer" });
    }

    const productResult = await queryOrDemo(
      "SELECT id, name, price FROM products WHERE id = $1", [productId],
      () => ({ rows: demoProducts.filter(p => p.id === productId) })
    );
    const product = productResult.rows[0];
    if (!product) return res.status(404).json({ error: "Product not found" });

    if (pool) {
      const result = await pool.query(
        `INSERT INTO cart_items (product_id, quantity) VALUES ($1, $2)
         ON CONFLICT (product_id) DO UPDATE SET quantity = cart_items.quantity + EXCLUDED.quantity
         RETURNING id, product_id AS "productId", quantity`,
        [productId, quantity]
      );
      return res.status(201).json({ ...result.rows[0], product });
    }

    let item = demoCart.find(x => x.productId === productId);
    if (item) item.quantity += quantity;
    else {
      item = { id: productId, productId, quantity };
      demoCart.push(item);
    }
    res.status(201).json({ ...item, product });
  } catch (err) { next(err); }
});

app.put("/api/cart/:id", async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const quantity = Number(req.body.quantity);
    if (!Number.isInteger(quantity) || quantity < 1) {
      return res.status(400).json({ error: "quantity must be a positive integer" });
    }

    if (pool) {
      const result = await pool.query(
        `UPDATE cart_items SET quantity = $1 WHERE product_id = $2
         RETURNING id, product_id AS "productId", quantity`,
        [quantity, id]
      );
      if (!result.rowCount) return res.status(404).json({ error: "Cart item not found" });
      return res.json(result.rows[0]);
    }

    const item = demoCart.find(x => x.productId === id);
    if (!item) return res.status(404).json({ error: "Cart item not found" });
    item.quantity = quantity;
    res.json(item);
  } catch (err) { next(err); }
});

app.delete("/api/cart/:id", async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (pool) {
      const result = await pool.query("DELETE FROM cart_items WHERE product_id = $1 RETURNING *", [id]);
      if (!result.rowCount) return res.status(404).json({ error: "Cart item not found" });
      return res.json({ message: "Cart item removed" });
    }
    const index = demoCart.findIndex(x => x.productId === id);
    if (index < 0) return res.status(404).json({ error: "Cart item not found" });
    demoCart.splice(index, 1);
    res.json({ message: "Cart item removed" });
  } catch (err) { next(err); }
});

app.post("/api/orders", async (_req, res, next) => {
  try {
    let items;
    if (pool) {
      const cart = await pool.query(
        `SELECT c.product_id AS "productId", c.quantity, p.name, p.price
         FROM cart_items c JOIN products p ON p.id = c.product_id ORDER BY c.product_id`
      );
      items = cart.rows;
      if (!items.length) return res.status(400).json({ error: "Cart is empty" });
      const total = calculateTotal(items);
      const result = await pool.query(
        "INSERT INTO orders (total, items) VALUES ($1, $2) RETURNING id, total, items, created_at",
        [total, JSON.stringify(items)]
      );
      await pool.query("DELETE FROM cart_items");
      return res.status(201).json(result.rows[0]);
    }

    items = demoCart.map(item => {
      const product = demoProducts.find(p => p.id === item.productId);
      return { productId: item.productId, name: product.name, price: product.price, quantity: item.quantity };
    });
    if (!items.length) return res.status(400).json({ error: "Cart is empty" });
    const order = {
      id: nextOrderId++,
      total: calculateTotal(items),
      items,
      createdAt: new Date().toISOString()
    };
    demoOrders.push(order);
    demoCart.length = 0;
    res.status(201).json(order);
  } catch (err) { next(err); }
});

app.get("/api/orders", async (_req, res, next) => {
  try {
    const result = await queryOrDemo(
      "SELECT id, total, items, created_at AS \"createdAt\" FROM orders ORDER BY id",
      [],
      () => ({ rows: demoOrders })
    );
    res.json(result.rows);
  } catch (err) { next(err); }
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

module.exports = app;
