import ProductCard from './ProductCard.jsx'

export default function ProductList({ products, search, onSearch, category, onCategory, onAdd }) {
  return <section className="products-section">
    <div className="section-heading"><div><span className="eyebrow">HANDPICKED FOR YOU</span><h2>Explore products</h2><p>Find the right picks for your everyday needs.</p></div><span className="result-count">{products.length} items</span></div>
    <div className="filters"><label className="search-box"><span>⌕</span><input value={search} onChange={e => onSearch(e.target.value)} placeholder="Search products..." /></label><select value={category} onChange={e => onCategory(e.target.value)} aria-label="Filter by category"><option>All</option><option>Electronics</option><option>Accessories</option><option>Fashion</option></select></div>
    <div className="product-grid">{products.length ? products.map(product => <ProductCard key={product.id} product={product} name={product.name} price={product.price} category={product.category} onAdd={onAdd} />) : <div className="no-products"><span>⌕</span><h3>No products found</h3><p>Try another search or category.</p></div>}</div>
  </section>
}
