export const students = [
  { id: '101', name: 'Rahul', branch: 'CSE', year: 'III', email: 'rahul@college.edu', cgpa: '8.6', status: 'Active' },
  { id: '102', name: 'Priya', branch: 'ECE', year: 'II', email: 'priya@college.edu', cgpa: '9.1', status: 'Active' },
  { id: '103', name: 'Arjun', branch: 'IT', year: 'IV', email: 'arjun@college.edu', cgpa: '8.2', status: 'Active' },
  { id: '104', name: 'Sneha', branch: 'CSE', year: 'III', email: 'sneha@college.edu', cgpa: '9.3', status: 'Active' },
  { id: '105', name: 'Kiran', branch: 'EEE', year: 'I', email: 'kiran@college.edu', cgpa: '7.9', status: 'Active' }
]

export const courses = [
  { id: 'CS301', name: 'Data Structures & Algorithms', department: 'Computer Science', credits: 4, semester: 'Semester 3', description: 'Core data structures, algorithm design, complexity analysis and problem solving.' },
  { id: 'CS402', name: 'Database Management Systems', department: 'Computer Science', credits: 3, semester: 'Semester 4', description: 'Relational databases, SQL, normalization, transactions and database design.' },
  { id: 'EC201', name: 'Digital Electronics', department: 'Electronics', credits: 4, semester: 'Semester 2', description: 'Digital logic, combinational circuits, sequential circuits and applications.' },
  { id: 'IT405', name: 'Web Technologies', department: 'Information Technology', credits: 3, semester: 'Semester 4', description: 'Modern web development concepts, frontend frameworks and REST APIs.' }
]
