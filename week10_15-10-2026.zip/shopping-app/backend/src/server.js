const { createApp } = require("./app");

const PORT = Number(process.env.PORT) || 5000;
createApp().listen(PORT, "0.0.0.0", () => {
  console.log(`Shopping API listening on port ${PORT}`);
});
