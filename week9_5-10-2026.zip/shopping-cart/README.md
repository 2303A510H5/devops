# Online Shopping Cart

A responsive React shopping-cart application demonstrating reusable components, props, and state management with `useState()`.

## Features
- Product listing with name, ID, category, price and product illustration
- Reusable `Header`, `ProductList`, `ProductCard`, `Cart`, `CartItem` and `Summary` components
- Add products, remove products, increase/decrease quantities and clear the cart
- Live item count and bill calculation
- Search products and filter by category
- 10% discount when subtotal exceeds ₹5,000
- Free delivery when subtotal exceeds ₹2,000
- Empty-cart conditional rendering and responsive layout

## Run locally
Install Node.js 18+ and open this folder in VS Code. In the terminal run:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually http://localhost:5173).

## Project structure
- `src/App.jsx` — parent component and cart state
- `src/data.js` — sample product data
- `src/components/` — reusable UI components
- `src/styles.css` — responsive styling

## State and props demonstration
The `App` component owns the cart state using `useState()`. It passes product data and event-handler functions to `ProductList` and `ProductCard`, and passes selected cart items and quantity handlers to `Cart` and `CartItem`. `Summary` receives calculated totals as props.

The discount is 10% of the subtotal when the subtotal is greater than ₹5,000. Free delivery is shown when the subtotal is greater than ₹2,000. The bill includes a ₹50 delivery charge when the subtotal is ₹2,000 or less and the cart is not empty.
