const BookManager = require('./books');
const MemberManager = require('./members');

const books = new BookManager();
const members = new MemberManager();

console.log('--- Library Book Management ---');
const book = books.addBook({
  title: 'The Alchemist',
  author: 'Paulo Coelho',
  isbn: '9780061122415',
  year: 1988
});
console.log('Added book:', book);
console.log('Search books by author:', books.searchBooks('Paulo'));

console.log('\n--- Library Member Management ---');
const member = members.registerMember({
  name: 'Aarav Sharma',
  email: 'aarav@example.com',
  phone: '9876543210'
});
console.log('Registered member:', member);
console.log('Search members:', members.searchMembers('aarav@example.com'));
