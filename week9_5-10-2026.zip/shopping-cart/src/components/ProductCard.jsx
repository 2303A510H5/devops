export default function ProductCard({ product, name, price, category, onAdd }) {
  return <article className="product-card">
    <div className={`product-art ${product.tone}`}><span>{product.icon}</span>{product.tag && <small className="product-tag">{product.tag}</small>}<span className="product-id">{product.id}</span></div>
    <div className="product-info"><span className="category">{category}</span><h3>{name}</h3><p>{product.description}</p><div className="product-bottom"><strong>{price.toLocaleString('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 })}</strong><button className="add-button" onClick={() => onAdd(product)} aria-label={`Add ${name} to cart`}>＋ Add</button></div></div>
  </article>
}
