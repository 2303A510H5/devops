import { Link } from 'react-router-dom'
import { students, courses } from '../data.js'
import StatCard from '../components/StatCard.jsx'

export default function Home() {
  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">ACADEMIC MANAGEMENT • 2026</span>
          <h1>College Student<br /><span>Management Portal</span></h1>
          <p>One place to explore student records, discover courses and stay connected with campus academics.</p>
          <div className="hero-actions"><Link className="btn btn-light" to="/students">Explore Students <span>→</span></Link><Link className="hero-text-link" to="/about">Learn more</Link></div>
        </div>
        <div className="hero-art" aria-hidden="true"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="cap">🎓</div><div className="art-chip chip-one">✦ Learn</div><div className="art-chip chip-two">✓ Grow</div></div>
      </section>
      <section className="stats-grid">
        <StatCard label="Registered Students" value={students.length} note="Across all departments" icon="♙" />
        <StatCard label="Available Courses" value={courses.length} note="Academic catalogue" icon="▤" />
        <StatCard label="Departments" value="04" note="Learning communities" icon="⌂" />
        <StatCard label="Academic Year" value="2026" note="Current session" icon="◷" />
      </section>
      <section className="section-heading"><div><span className="eyebrow">QUICK ACCESS</span><h2>Explore the portal</h2></div><p>Choose a section to get started.</p></section>
      <div className="quick-grid">
        <Link to="/students" className="quick-card"><span className="quick-icon purple">♙</span><h3>Student Directory</h3><p>Browse student profiles and academic information.</p><b>View students →</b></Link>
        <Link to="/courses" className="quick-card"><span className="quick-icon blue">▤</span><h3>Course Catalogue</h3><p>Explore available courses and course details.</p><b>Browse courses →</b></Link>
        <Link to="/about" className="quick-card"><span className="quick-icon green">ⓘ</span><h3>About the Portal</h3><p>Learn about the purpose and features of this portal.</p><b>Discover more →</b></Link>
      </div>
    </>
  )
}
