const { ValidationError, UniqueConstraintError, ForeignKeyConstraintError } = require('sequelize');

function errorHandler(err, req, res, next) {
  console.error(err);

  if (err instanceof UniqueConstraintError) {
    return res.status(409).json({ success: false, message: 'A book with this ISBN already exists', errors: err.errors.map(e => e.message) });
  }
  if (err instanceof ValidationError) {
    return res.status(400).json({ success: false, message: 'Validation failed', errors: err.errors.map(e => e.message) });
  }
  if (err instanceof ForeignKeyConstraintError) {
    return res.status(400).json({ success: false, message: 'Database constraint error' });
  }
  if (err.name === 'SequelizeConnectionError' || err.name === 'SequelizeConnectionRefusedError') {
    return res.status(503).json({ success: false, message: 'Database unavailable. Check that PostgreSQL is running and connection settings are correct.' });
  }
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal server error'
  });
}

module.exports = errorHandler;
