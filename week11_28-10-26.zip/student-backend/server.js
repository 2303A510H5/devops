const express = require("express");

const app = express();
const PORT = Number(process.env.PORT) || 5000;

app.disable("x-powered-by");
app.use(express.json());

const students = [
  {
    id: 1,
    name: "Rahul",
    rollNo: "CSE101",
    branch: "CSE"
  },
  {
    id: 2,
    name: "Priya",
    rollNo: "CSE102",
    branch: "CSE"
  }
];

app.get("/", (_req, res) => {
  res.send("Student Management API");
});

app.get("/health", (_req, res) => {
  res.status(200).json({
    status: "UP",
    service: "Student Management API"
  });
});

app.get("/api/students", (_req, res) => {
  res.json(students);
});

app.get("/api/students/:id", (req, res) => {
  const student = students.find(item => item.id === Number(req.params.id));
  if (!student) {
    return res.status(404).json({ error: "Student not found" });
  }
  res.json(student);
});

app.use((req, res) => {
  res.status(404).json({ error: "Route not found", path: req.originalUrl });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Student Management API running on port ${PORT}`);
});
