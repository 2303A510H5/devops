import StudentCard from "./StudentCard";

export default function StudentList({ students, onDelete, onEdit }) {
  if (!students.length) {
    return <div className="empty-state"><div className="empty-icon">⌕</div><h3>No students found</h3><p>Try changing your search or add a new student.</p></div>;
  }

  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr><th>Roll Number</th><th>Student Name</th><th>Branch</th><th>Actions</th></tr>
        </thead>
        <tbody>
          {students.map(student => (
            <StudentCard key={student.id} student={student} onDelete={onDelete} onEdit={onEdit} />
          ))}
        </tbody>
      </table>
    </div>
  );
}
