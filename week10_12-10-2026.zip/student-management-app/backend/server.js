const express = require("express");
const cors = require("cors");

const app = express();
const PORT = Number(process.env.PORT) || 5000;

app.use(cors());
app.use(express.json());

let students = [
  { id: 1, name: "Rahul", rollNo: "CSE101", branch: "CSE" },
  { id: 2, name: "Priya", rollNo: "CSE102", branch: "CSE" }
];
let nextId = 3;

app.get("/", (_req, res) => {
  res.send("College Student Management API");
});

app.get("/health", (_req, res) => {
  res.json({ status: "UP", service: "Student Management API" });
});

app.get("/api/students", (_req, res) => {
  res.json(students);
});

app.get("/api/students/:id", (req, res) => {
  const student = students.find(item => item.id === Number(req.params.id));
  if (!student) return res.status(404).json({ error: "Student not found" });
  res.json(student);
});

app.post("/api/students", (req, res) => {
  const { name, rollNo, branch } = req.body || {};
  if (
    typeof name !== "string" || !name.trim() ||
    typeof rollNo !== "string" || !rollNo.trim() ||
    typeof branch !== "string" || !branch.trim()
  ) {
    return res.status(400).json({
      error: "Name, roll number, and branch are required"
    });
  }

  if (students.some(item => item.rollNo.toLowerCase() === rollNo.trim().toLowerCase())) {
    return res.status(409).json({ error: "Roll number already exists" });
  }

  const student = {
    id: nextId++,
    name: name.trim(),
    rollNo: rollNo.trim().toUpperCase(),
    branch: branch.trim().toUpperCase()
  };
  students.push(student);
  res.status(201).json(student);
});

app.put("/api/students/:id", (req, res) => {
  const student = students.find(item => item.id === Number(req.params.id));
  if (!student) return res.status(404).json({ error: "Student not found" });

  const { name, rollNo, branch } = req.body || {};
  if (
    typeof name !== "string" || !name.trim() ||
    typeof rollNo !== "string" || !rollNo.trim() ||
    typeof branch !== "string" || !branch.trim()
  ) {
    return res.status(400).json({
      error: "Name, roll number, and branch are required"
    });
  }

  const duplicate = students.some(item =>
    item.id !== student.id &&
    item.rollNo.toLowerCase() === rollNo.trim().toLowerCase()
  );
  if (duplicate) return res.status(409).json({ error: "Roll number already exists" });

  student.name = name.trim();
  student.rollNo = rollNo.trim().toUpperCase();
  student.branch = branch.trim().toUpperCase();
  res.json(student);
});

app.delete("/api/students/:id", (req, res) => {
  const index = students.findIndex(item => item.id === Number(req.params.id));
  if (index === -1) return res.status(404).json({ error: "Student not found" });

  const [deletedStudent] = students.splice(index, 1);
  res.json({ message: "Student deleted successfully", student: deletedStudent });
});

app.use((req, res) => {
  res.status(404).json({ error: "Route not found", path: req.originalUrl });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Student Management API running at http://localhost:${PORT}`);
});
