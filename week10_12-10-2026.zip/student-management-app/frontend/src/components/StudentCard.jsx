import { Link } from "react-router-dom";

export default function StudentCard({ student, onDelete, onEdit }) {
  return (
    <tr>
      <td><span className="roll-badge">{student.rollNo}</span></td>
      <td className="student-name">{student.name}</td>
      <td><span className="branch-badge">{student.branch}</span></td>
      <td className="table-actions">
        <Link className="icon-button view-button" to={`/students/${student.id}`} title="View details" aria-label={`View ${student.name}`}>View</Link>
        <button className="icon-button edit-button" onClick={() => onEdit(student)} aria-label={`Edit ${student.name}`}>Edit</button>
        <button className="icon-button delete-button" onClick={() => onDelete(student)} aria-label={`Delete ${student.name}`}>Delete</button>
      </td>
    </tr>
  );
}
