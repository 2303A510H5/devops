const express = require("express");
const cors = require("cors");

function createApp() {
  const app = express();
  app.use(cors());
  app.use(express.json());

  let products = [
    { id: 1, name: "Laptop", price: 60000, category: "Electronics" },
    { id: 2, name: "Headphones", price: 2000, category: "Electronics" }
  ];
  let nextId = 3;

  app.get("/health", (_req, res) => res.json({ status: "UP", service: "Shopping API" }));

  app.get("/api/products", (_req, res) => res.json(products));

  app.get("/api/products/:id", (req, res) => {
    const product = products.find(item => item.id === Number(req.params.id));
    if (!product) return res.status(404).json({ error: "Product not found" });
    res.json(product);
  });

  app.post("/api/products", (req, res) => {
    const { name, price, category } = req.body || {};
    if (typeof name !== "string" || !name.trim() ||
        !Number.isFinite(Number(price)) || Number(price) <= 0 ||
        typeof category !== "string" || !category.trim()) {
      return res.status(400).json({ error: "name, positive price, and category are required" });
    }
    const product = { id: nextId++, name: name.trim(), price: Number(price), category: category.trim() };
    products.push(product);
    res.status(201).json(product);
  });

  app.put("/api/products/:id", (req, res) => {
    const product = products.find(item => item.id === Number(req.params.id));
    if (!product) return res.status(404).json({ error: "Product not found" });
    const { name, price, category } = req.body || {};
    if (name !== undefined && (typeof name !== "string" || !name.trim())) {
      return res.status(400).json({ error: "name must be a non-empty string" });
    }
    if (price !== undefined && (!Number.isFinite(Number(price)) || Number(price) <= 0)) {
      return res.status(400).json({ error: "price must be positive" });
    }
    if (category !== undefined && (typeof category !== "string" || !category.trim())) {
      return res.status(400).json({ error: "category must be a non-empty string" });
    }
    if (name !== undefined) product.name = name.trim();
    if (price !== undefined) product.price = Number(price);
    if (category !== undefined) product.category = category.trim();
    res.json(product);
  });

  app.delete("/api/products/:id", (req, res) => {
    const index = products.findIndex(item => item.id === Number(req.params.id));
    if (index < 0) return res.status(404).json({ error: "Product not found" });
    const [deleted] = products.splice(index, 1);
    res.json({ message: "Product deleted successfully", product: deleted });
  });

  app.use((req, res) => res.status(404).json({ error: "Route not found" }));
  return app;
}

module.exports = { createApp };
