export default function Footer() {
  return <footer className="footer"><div className="container footer-inner"><span>© 2026 SR University. All rights reserved.</span><span>Student Management Dashboard <i>·</i> Academic Services</span></div></footer>
}
