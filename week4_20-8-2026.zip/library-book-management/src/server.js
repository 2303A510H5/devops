require('dotenv').config();
const app = require('./app');
const sequelize = require('./config/database');
require('./models/Book');

const PORT = process.env.PORT || 5000;

async function startServer() {
  try {
    await sequelize.authenticate();
    console.log('PostgreSQL connection established successfully.');
    await sequelize.sync();
    console.log('Database models synchronized.');
    app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
  } catch (error) {
    console.error('Unable to start application. Check PostgreSQL and your .env configuration.');
    console.error(error.message);
    process.exit(1);
  }
}

startServer();
