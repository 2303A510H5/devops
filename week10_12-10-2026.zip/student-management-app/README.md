# College Student Management System

A full-stack student dashboard built with React, Vite, Node.js, and Express. It displays student records in a table and supports adding, editing, deleting, searching, filtering, and viewing student details.

## Project structure

```text
student-management-app/
├── backend/
│   ├── server.js
│   └── package.json
└── frontend/
    ├── index.html
    ├── package.json
    ├── vite.config.js
    └── src/
        ├── components/
        ├── pages/
        ├── services/
        ├── App.jsx
        ├── main.jsx
        └── styles.css
```

## Requirements

- Node.js 20 or later
- npm
- Visual Studio Code (recommended)

## Run the backend

Open a terminal:

```bash
cd backend
npm install
npm start
```

The backend runs at `http://localhost:5000`.

## Run the React frontend

Open a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal, normally `http://localhost:5173`.

The Vite development server proxies `/api` requests to `http://localhost:5000`.

## Features

- Student listing in a responsive table
- Add student with name, roll number, and branch
- Edit student details
- Delete student with confirmation
- Search by student name or roll number
- Filter by branch
- Student details page using React Router
- Total student and branch counts
- Loading, success, and error messages
- Backend input validation and duplicate roll-number handling

## REST API endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/students` | List students |
| GET | `/api/students/:id` | Get one student |
| POST | `/api/students` | Add a student |
| PUT | `/api/students/:id` | Update a student |
| DELETE | `/api/students/:id` | Delete a student |
| GET | `/health` | Backend health check |

### Sample POST body

```json
{
  "name": "Ananya",
  "rollNo": "CSE103",
  "branch": "CSE"
}
```

## Important note about storage

This assessment version uses an in-memory array in the backend. Newly added or updated students are not persisted after the backend process restarts. A database such as MongoDB or PostgreSQL can be added for permanent storage.
