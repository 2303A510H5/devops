const money = value => value.toLocaleString('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 })

export default function CartItem({ item, name, price, quantity, onRemove, onChangeQuantity }) {
  return <div className="cart-item"><div className={`mini-art ${item.tone}`}>{item.icon}</div><div className="cart-item-info"><strong>{name}</strong><small>{item.id} · {money(price)}</small><div className="quantity-control"><button onClick={() => onChangeQuantity(item.id, -1)} disabled={quantity <= 1} aria-label={`Decrease ${name} quantity`}>−</button><span>{quantity}</span><button onClick={() => onChangeQuantity(item.id, 1)} aria-label={`Increase ${name} quantity`}>＋</button></div></div><div className="cart-item-end"><strong>{money(price * quantity)}</strong><button className="remove-button" onClick={() => onRemove(item.id)}>Remove</button></div></div>
}
