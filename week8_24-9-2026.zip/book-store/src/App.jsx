import { useState } from 'react'
import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar.jsx'
import Home from './pages/Home.jsx'
import Books from './pages/Books.jsx'
import BookDetails from './pages/BookDetails.jsx'
import Cart from './pages/Cart.jsx'
import About from './pages/About.jsx'
import NotFound from './pages/NotFound.jsx'

export default function App() {
  const [cart, setCart] = useState([])

  const addToCart = (book) => {
    setCart(current => {
      const existing = current.find(item => item.id === book.id)
      if (existing) return current.map(item => item.id === book.id ? { ...item, quantity: item.quantity + 1 } : item)
      return [...current, { ...book, quantity: 1 }]
    })
  }
  const removeFromCart = id => setCart(current => current.filter(item => item.id !== id))
  const updateQuantity = (id, change) => setCart(current => current.map(item => item.id === id ? { ...item, quantity: Math.max(1, item.quantity + change) } : item))
  const clearCart = () => setCart([])

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0)

  return <div className="app-shell">
    <Navbar cartCount={cartCount} />
    <main className="container main-content">
      <Routes>
        <Route path="/" element={<Home onAdd={addToCart} />} />
        <Route path="/books" element={<Books onAdd={addToCart} />} />
        <Route path="/books/:id" element={<BookDetails onAdd={addToCart} />} />
        <Route path="/cart" element={<Cart items={cart} onRemove={removeFromCart} onUpdateQuantity={updateQuantity} onClear={clearCart} />} />
        <Route path="/about" element={<About />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </main>
    <footer className="footer">© 2026 The Reading Room <span>A little more reading, a lot more wonder.</span></footer>
  </div>
}
