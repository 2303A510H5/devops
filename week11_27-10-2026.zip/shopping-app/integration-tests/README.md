# Integration tests

Run the backend first, then run:

```bash
npm test
```

By default the tests call `http://localhost:5000`. Set `API_URL` to override it.

The workflow test verifies product listing and details, add-to-cart, quantity update, order creation, calculated total, and order history. The quantity assertion catches the described cart-update regression.
