# College Student Management Portal

A React + Vite single-page application demonstrating React Router and functional-component lifecycle behavior with `useEffect`.

## Features
- Home, Students, Student Details, Courses, Course Details and About pages
- Client-side navigation using `NavLink`, `Link` and `useNavigate` (no full-page reload)
- Dynamic routes with `useParams()`
- Lifecycle logging and cleanup with `useEffect()`
- Simulated asynchronous student loading, loading state and not-found error
- Student search, active navigation styling, back button and 404 page
- Responsive dashboard layout

## Requirements
- Node.js 18+ (LTS recommended)
- VS Code or another code editor

## Run locally
Open this folder in VS Code, then run these commands in the terminal:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually http://localhost:5173).

## Routes
| URL | Page |
|---|---|
| `/` | Home |
| `/students` | Student list |
| `/students/:id` | Student details |
| `/courses` | Course list |
| `/courses/:id` | Course details |
| `/about` | About |
| `*` | 404 Not Found |

## Lifecycle demonstration
- `useEffect(..., [])` logs when the StudentList component mounts and logs cleanup when it unmounts.
- StudentDetails loads the selected student asynchronously. Its effect reruns when the route `id` changes and clears its pending timer on cleanup.
- Open the browser developer console to see lifecycle messages.

## Notes
The sample records are stored in `src/data.js`; the loading delay simulates an API request. This is a frontend learning project and does not require a backend.
