# Week 11 Assessment — Dockerizing an Online Shopping Backend

## Overview
A Node.js 20 + Express REST API that supports creating, reading, updating, and deleting products. It includes a health endpoint and a production-oriented Dockerfile.

> **Assessment note:** Product data is stored in memory for this exercise. Products added, updated, or deleted will reset to the sample data when the server/container is recreated. A persistent database is not included in the scenario requirements.

## Project structure
```text
shopping-backend/
├── server.js
├── package.json
├── package-lock.json
├── .dockerignore
├── .env.example
├── Dockerfile
└── README.md
```

## Run locally
Requires Node.js 20 or later.
```bash
npm ci
npm start
```
The server listens at `http://localhost:5000` by default.

## API endpoints
| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Health status |
| GET | `/api/products` | List all products |
| GET | `/api/products/:id` | Get a product by ID |
| POST | `/api/products` | Create a product |
| PUT | `/api/products/:id` | Update a product |
| DELETE | `/api/products/:id` | Delete a product |

## Postman testing
Base URL: `http://localhost:5000`

### GET all products
`GET http://localhost:5000/api/products`

### GET product by ID
`GET http://localhost:5000/api/products/1`

### POST create product
- Method: `POST`
- URL: `http://localhost:5000/api/products`
- Header: `Content-Type: application/json`
- Body → raw → JSON:
```json
{
  "name": "Smartphone",
  "price": 25000,
  "category": "Electronics"
}
```

### PUT update product
- Method: `PUT`
- URL: `http://localhost:5000/api/products/1`
- Header: `Content-Type: application/json`
- Body → raw → JSON:
```json
{
  "name": "Updated Laptop",
  "price": 65000,
  "category": "Electronics"
}
```

### DELETE product
`DELETE http://localhost:5000/api/products/1`

## Build Docker image
Run from the `shopping-backend` directory:
```bash
docker build -t shopping-backend:v1 .
docker images
```

## Run container
```bash
docker run -d \
  -p 5000:5000 \
  --name shopping-api \
  -e PORT=5000 \
  -e NODE_ENV=production \
  --restart unless-stopped \
  shopping-backend:v1
```

To use port 6000 both inside and outside the container:
```bash
docker rm -f shopping-api
docker run -d -p 6000:6000 -e PORT=6000 \
  --name shopping-api --restart unless-stopped shopping-backend:v1
```
Then access `http://localhost:6000`.

## Container verification and logs
```bash
docker ps
docker logs shopping-api
docker inspect shopping-api
docker inspect --format='{{.State.Health.Status}}' shopping-api
```

## Image tagging and Docker Hub
Replace `<username>` with your Docker Hub username:
```bash
docker login
docker tag shopping-backend:v1 <username>/shopping-backend:v1
docker push <username>/shopping-backend:v1
```

On another system:
```bash
docker pull <username>/shopping-backend:v1
docker run -d -p 5000:5000 --name shopping-api <username>/shopping-backend:v1
```

## Cleanup
```bash
docker rm -f shopping-api
```

## Production-oriented Docker features
- Uses the lightweight `node:20-alpine` base image.
- Installs only production dependencies with `npm ci --omit=dev`.
- Uses `.dockerignore` to exclude `node_modules`, Git files, and environment files.
- Runs the app as the non-root `node` user.
- Supports `PORT` and `NODE_ENV` environment variables.
- Includes `/health` and a Docker `HEALTHCHECK`.
- Documents image tagging, container logs, and restart policy.
