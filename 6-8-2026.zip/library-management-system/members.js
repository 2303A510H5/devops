// Library member management module
class MemberManager {
  constructor(initialMembers = []) {
    this.members = initialMembers.map(member => ({ ...member }));
    this.nextId = this.members.reduce((max, member) => Math.max(max, member.id || 0), 0) + 1;
  }

  registerMember({ name, email, phone }) {
    if (!name || !email) throw new Error('Member name and email are required');
    const normalizedEmail = email.trim().toLowerCase();
    if (this.members.some(member => member.email.toLowerCase() === normalizedEmail)) {
      throw new Error('A member with this email is already registered');
    }
    const member = {
      id: this.nextId++,
      name: name.trim(),
      email: normalizedEmail,
      phone: phone ? String(phone).trim() : ''
    };
    this.members.push(member);
    return { ...member };
  }

  updateMember(id, updates) {
    const member = this.members.find(item => item.id === Number(id));
    if (!member) return null;
    if (updates.email) {
      const email = updates.email.trim().toLowerCase();
      if (this.members.some(item => item.id !== member.id && item.email.toLowerCase() === email)) {
        throw new Error('A member with this email is already registered');
      }
      member.email = email;
    }
    if (updates.name !== undefined) member.name = updates.name.trim();
    if (updates.phone !== undefined) member.phone = String(updates.phone).trim();
    return { ...member };
  }

  searchMembers(query) {
    const term = String(query || '').toLowerCase();
    return this.members
      .filter(member => [member.name, member.email, member.phone].some(value => String(value).toLowerCase().includes(term)))
      .map(member => ({ ...member }));
  }

  removeMember(id) {
    const index = this.members.findIndex(member => member.id === Number(id));
    if (index === -1) return null;
    return this.members.splice(index, 1)[0];
  }

  getAllMembers() {
    return this.members.map(member => ({ ...member }));
  }
}

module.exports = MemberManager;
