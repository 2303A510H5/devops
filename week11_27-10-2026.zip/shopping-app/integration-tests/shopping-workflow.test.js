const test = require("node:test");
const assert = require("node:assert/strict");

const BASE_URL = process.env.API_URL || "http://localhost:5000";

async function request(path, options = {}) {
  const response = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const text = await response.text();
  let body;
  try { body = text ? JSON.parse(text) : null; } catch { body = text; }
  return { status: response.status, body };
}

test("complete product-to-order shopping workflow", async () => {
  // 1. Retrieve products
  const products = await request("/api/products");
  assert.equal(products.status, 200);
  assert.ok(Array.isArray(products.body));
  const laptop = products.body.find(p => p.id === 101);
  assert.ok(laptop, "Laptop product should be available");
  assert.equal(Number(laptop.price), 60000);

  // 2. Retrieve product details
  const details = await request("/api/products/101");
  assert.equal(details.status, 200);
  assert.equal(details.body.name, "Laptop");

  // 3. Add product to cart
  const added = await request("/api/cart", {
    method: "POST",
    body: JSON.stringify({ productId: 101, quantity: 1 })
  });
  assert.equal(added.status, 201);
  assert.equal(added.body.productId, 101);

  // 4. Update quantity (the key regression assertion)
  const updated = await request("/api/cart/101", {
    method: "PUT",
    body: JSON.stringify({ quantity: 2 })
  });
  assert.equal(updated.status, 200);
  assert.equal(updated.body.quantity, 2);

  // 5. Place order and verify computed total
  const placed = await request("/api/orders", { method: "POST" });
  assert.equal(placed.status, 201);
  assert.equal(Number(placed.body.total), 120000);
  assert.ok(placed.body.id);

  // 6. Retrieve order history
  const history = await request("/api/orders");
  assert.equal(history.status, 200);
  assert.ok(history.body.some(order => order.id === placed.body.id));
});
