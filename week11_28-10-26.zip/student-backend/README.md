# Week 11 Assessment — Dockerizing a College Student Management Backend

## Overview
A simple Node.js 20 + Express REST API that returns college student information. The project includes a Dockerfile, environment-based port configuration, a non-root container user, and a health check.

## Project structure
```text
student-backend/
├── server.js
├── package.json
├── package-lock.json
├── .dockerignore
├── .env.example
├── Dockerfile
└── README.md
```

## Run locally
Requires Node.js 20 or later.
```bash
npm ci
npm start
```
Open:
- `http://localhost:5000`
- `http://localhost:5000/api/students`
- `http://localhost:5000/api/students/1`
- `http://localhost:5000/health`

## API endpoints
| Method | Endpoint | Description |
|---|---|---|
| GET | `/` | API welcome message |
| GET | `/health` | Health status |
| GET | `/api/students` | List all students |
| GET | `/api/students/:id` | Get student by ID |

## Build Docker image
Run these commands from this directory:
```bash
docker build -t student-backend:v1 .
docker images
```

## Run container
```bash
docker run -d \
  -p 5000:5000 \
  -e PORT=5000 \
  --name student-container \
  student-backend:v1
```

To map host port 6000 to container port 6000:
```bash
docker rm -f student-container
docker run -d -p 6000:6000 -e PORT=6000 \
  --name student-container student-backend:v1
```
Then open `http://localhost:6000/api/students`.

## Verify and manage container
```bash
docker ps
docker logs student-container
docker inspect student-container
docker inspect --format='{{.State.Health.Status}}' student-container
docker stop student-container
docker start student-container
docker rm -f student-container
```

## Image versioning
```bash
docker build -t student-backend:v1 .
docker tag student-backend:v1 student-backend:v2
docker images
```

## Docker Hub bonus
Replace `<username>` with your Docker Hub username:
```bash
docker login
docker tag student-backend:v1 <username>/student-backend:v1
docker push <username>/student-backend:v1
```

On another system:
```bash
docker pull <username>/student-backend:v1
docker run -d -p 5000:5000 --name student-container <username>/student-backend:v1
```

## Production-oriented Docker features
- Uses the lightweight `node:20-alpine` image.
- Installs production dependencies using `npm ci --omit=dev`.
- `.dockerignore` excludes local dependencies, Git metadata, and environment files.
- Runs as the non-root `node` user.
- Supports the `PORT` environment variable.
- Includes `/health` and a Docker `HEALTHCHECK`.
- Supports versioned image tags.
