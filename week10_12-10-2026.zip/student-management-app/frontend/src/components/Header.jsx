import { Link, NavLink } from "react-router-dom";

export default function Header() {
  return (
    <header className="topbar">
      <Link to="/" className="brand">
        <span className="brand-mark">S</span>
        <span>Campus<span className="brand-light">Connect</span></span>
      </Link>
      <nav>
        <NavLink to="/" end>Dashboard</NavLink>
      </nav>
    </header>
  );
}
