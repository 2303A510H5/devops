const request = require("supertest");
const { createApp } = require("../src/app");

describe("Products API", () => {
  let app;
  beforeEach(() => { app = createApp(); });

  test("GET returns the product list", async () => {
    const response = await request(app).get("/api/products");
    expect(response.statusCode).toBe(200);
    expect(response.body).toHaveLength(2);
    expect(response.body[0].name).toBe("Laptop");
  });

  test("POST creates a product", async () => {
    const response = await request(app).post("/api/products")
      .send({ name: "Mouse", price: 800, category: "Electronics" });
    expect(response.statusCode).toBe(201);
    expect(response.body.name).toBe("Mouse");
  });

  test("PUT updates a product", async () => {
    const response = await request(app).put("/api/products/1")
      .send({ name: "Gaming Laptop", price: 75000, category: "Electronics" });
    expect(response.statusCode).toBe(200);
    expect(response.body.name).toBe("Gaming Laptop");
    expect(response.body.price).toBe(75000);
  });

  test("DELETE removes a product", async () => {
    const response = await request(app).delete("/api/products/1");
    expect(response.statusCode).toBe(200);
    const list = await request(app).get("/api/products");
    expect(list.body.some(product => product.id === 1)).toBe(false);
  });

  test("rejects invalid product data", async () => {
    const response = await request(app).post("/api/products")
      .send({ name: "", price: -10, category: "" });
    expect(response.statusCode).toBe(400);
  });
});
