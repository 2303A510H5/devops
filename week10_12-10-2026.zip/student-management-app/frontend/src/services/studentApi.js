const API_BASE = import.meta.env.VITE_API_URL || "";

async function handleResponse(response) {
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || `Request failed (${response.status})`);
  }
  return data;
}

export async function getStudents() {
  return handleResponse(await fetch(`${API_BASE}/api/students`));
}

export async function getStudent(id) {
  return handleResponse(await fetch(`${API_BASE}/api/students/${id}`));
}

export async function createStudent(student) {
  return handleResponse(await fetch(`${API_BASE}/api/students`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(student)
  }));
}

export async function updateStudent(id, student) {
  return handleResponse(await fetch(`${API_BASE}/api/students/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(student)
  }));
}

export async function deleteStudent(id) {
  return handleResponse(await fetch(`${API_BASE}/api/students/${id}`, {
    method: "DELETE"
  }));
}
