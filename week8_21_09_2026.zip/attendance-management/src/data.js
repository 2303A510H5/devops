export const initialStudents = [
  { id: 1, name: 'Rahul Sharma', rollNo: 'CSE101', branch: 'CSE', attendance: 86, today: null },
  { id: 2, name: 'Priya Reddy', rollNo: 'CSE102', branch: 'CSE', attendance: 92, today: null },
  { id: 3, name: 'Arjun Kumar', rollNo: 'ECE103', branch: 'ECE', attendance: 72, today: null },
  { id: 4, name: 'Sneha Patel', rollNo: 'IT104', branch: 'IT', attendance: 78, today: null },
  { id: 5, name: 'Kiran Rao', rollNo: 'EEE105', branch: 'EEE', attendance: 68, today: null },
  { id: 6, name: 'Ananya Das', rollNo: 'CSE106', branch: 'CSE', attendance: 95, today: null },
  { id: 7, name: 'Vikram Singh', rollNo: 'ECE107', branch: 'ECE', attendance: 74, today: null },
  { id: 8, name: 'Meera Nair', rollNo: 'IT108', branch: 'IT', attendance: 88, today: null }
]
