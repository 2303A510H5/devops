const express = require('express');
const router = express.Router();

// In-memory sample data. Records reset when the server restarts.
let books = [
  { id: 1, title: 'The Alchemist', author: 'Paulo Coelho', isbn: '9780061122415', available: true },
  { id: 2, title: 'Wings of Fire', author: 'A. P. J. Abdul Kalam', isbn: '9788173711466', available: true },
  { id: 3, title: 'The Guide', author: 'R. K. Narayan', isbn: '9780143039648', available: false }
];
let nextId = Math.max(...books.map(book => book.id)) + 1;

function validateBook(body, partial = false) {
  const errors = [];
  const required = ['title', 'author', 'isbn', 'available'];

  if (!partial) {
    for (const field of required) {
      if (body[field] === undefined || body[field] === null || body[field] === '') {
        errors.push(`${field} is required`);
      }
    }
  }

  if (body.title !== undefined && (typeof body.title !== 'string' || !body.title.trim())) {
    errors.push('title must be a non-empty string');
  }
  if (body.author !== undefined && (typeof body.author !== 'string' || !body.author.trim())) {
    errors.push('author must be a non-empty string');
  }
  if (body.isbn !== undefined && (typeof body.isbn !== 'string' || !/^[0-9Xx-]{10,17}$/.test(body.isbn))) {
    errors.push('isbn must contain 10–17 digits, X, or hyphens');
  }
  if (body.available !== undefined && typeof body.available !== 'boolean') {
    errors.push('available must be true or false');
  }

  return errors;
}

// GET /books - retrieve all books
router.get('/', (req, res) => {
  res.status(200).json({ success: true, count: books.length, data: books });
});

// GET /books/:id - retrieve a book by ID
router.get('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    return res.status(400).json({ success: false, message: 'Book ID must be a positive integer' });
  }

  const book = books.find(item => item.id === id);
  if (!book) {
    return res.status(404).json({ success: false, message: 'Book not found or unavailable in the library' });
  }

  res.status(200).json({ success: true, data: book });
});

// POST /books - add a new book
router.post('/', (req, res) => {
  const errors = validateBook(req.body);
  if (errors.length) {
    return res.status(400).json({ success: false, message: 'Validation failed', errors });
  }

  if (books.some(book => book.isbn === req.body.isbn.trim())) {
    return res.status(409).json({ success: false, message: 'A book with this ISBN already exists' });
  }

  const book = {
    id: nextId++,
    title: req.body.title.trim(),
    author: req.body.author.trim(),
    isbn: req.body.isbn.trim(),
    available: req.body.available
  };

  books.push(book);
  res.status(201).json({ success: true, message: 'Book added successfully', data: book });
});

// PUT /books/:id - update book information
router.put('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    return res.status(400).json({ success: false, message: 'Book ID must be a positive integer' });
  }

  const book = books.find(item => item.id === id);
  if (!book) {
    return res.status(404).json({ success: false, message: 'Book not found or unavailable in the library' });
  }

  const errors = validateBook(req.body, true);
  if (errors.length) {
    return res.status(400).json({ success: false, message: 'Validation failed', errors });
  }

  if (req.body.isbn && books.some(item => item.id !== id && item.isbn === req.body.isbn.trim())) {
    return res.status(409).json({ success: false, message: 'A book with this ISBN already exists' });
  }

  for (const field of ['title', 'author', 'isbn', 'available']) {
    if (req.body[field] !== undefined) {
      book[field] = typeof req.body[field] === 'string' ? req.body[field].trim() : req.body[field];
    }
  }

  res.status(200).json({ success: true, message: 'Book updated successfully', data: book });
});

// DELETE /books/:id - remove a book
router.delete('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    return res.status(400).json({ success: false, message: 'Book ID must be a positive integer' });
  }

  const index = books.findIndex(item => item.id === id);
  if (index === -1) {
    return res.status(404).json({ success: false, message: 'Book not found or unavailable in the library' });
  }

  const deletedBook = books.splice(index, 1)[0];
  res.status(200).json({ success: true, message: 'Book deleted successfully', data: deletedBook });
});

module.exports = router;
