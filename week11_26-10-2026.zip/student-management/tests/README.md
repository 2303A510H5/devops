# Student Management integration tests

The backend integration suite is implemented with Jest and Supertest in `backend/tests/integration.test.js`.

It validates:
1. Student registration (`POST /api/students`)
2. Student listing and retrieval (`GET /api/students`, `GET /api/students/:id`)
3. Student update (`PUT /api/students/:id`)
4. Student deletion (`DELETE /api/students/:id`)
5. Deleted student returns HTTP 404
6. Invalid student data returns HTTP 400

CI uses a dedicated PostgreSQL service database. When `DATABASE_URL` is not supplied, the API uses an in-memory fallback for convenient local execution.
