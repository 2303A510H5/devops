import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { students } from '../data.js'

export default function StudentList() {
  const [query, setQuery] = useState('')
  const [branch, setBranch] = useState('All')
  useEffect(() => {
    console.log('StudentList: Component Mounted')
    return () => console.log('StudentList: Component Unmounted')
  }, [])

  const filtered = useMemo(() => students.filter(student => {
    const matchesQuery = `${student.name} ${student.id} ${student.branch}`.toLowerCase().includes(query.toLowerCase())
    return matchesQuery && (branch === 'All' || student.branch === branch)
  }), [query, branch])

  return (
    <>
      <div className="page-title-row"><div><span className="eyebrow">CAMPUS DIRECTORY</span><h1>Students</h1><p className="muted">Search and view student academic profiles.</p></div><span className="count-pill">{filtered.length} students</span></div>
      <section className="panel">
        <div className="toolbar"><label className="search-box"><span>⌕</span><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search by name, ID or branch..." /></label><select value={branch} onChange={e => setBranch(e.target.value)} aria-label="Filter by branch"><option>All</option><option>CSE</option><option>ECE</option><option>IT</option><option>EEE</option></select></div>
        {filtered.length ? <div className="table-wrap"><table><thead><tr><th>STUDENT</th><th>STUDENT ID</th><th>BRANCH</th><th>YEAR</th><th>STATUS</th><th></th></tr></thead><tbody>{filtered.map(student => <tr key={student.id}><td><div className="student-cell"><span className="avatar">{student.name.charAt(0)}</span><strong>{student.name}</strong></div></td><td className="id-text">{student.id}</td><td><span className="branch-tag">{student.branch}</span></td><td>{student.year}</td><td><span className="status"><i></i>{student.status}</span></td><td><Link className="view-link" to={`/students/${student.id}`}>View details ↗</Link></td></tr>)}</tbody></table></div> : <div className="empty-state"><span>⌕</span><h3>No students found</h3><p>Try changing your search or branch filter.</p></div>}
      </section>
    </>
  )
}
