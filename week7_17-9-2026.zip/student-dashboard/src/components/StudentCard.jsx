export default function StudentCard({ student, selected, onViewProfile }) {
  return <article className={`student-card ${selected ? 'selected' : ''}`}><div className={`mini-avatar avatar-${student.id}`}>{student.avatar}</div><div className="student-card-info"><strong>{student.name}</strong><small>{student.rollNo} · {student.shortBranch}</small></div><button className="view-profile" onClick={onViewProfile}>{selected ? 'Viewing' : 'View Profile'} <span>→</span></button></article>
}
