import { useMemo, useState } from 'react'
import { books } from '../data.js'
import BookCard from '../components/BookCard.jsx'

export default function Books({ onAdd }) {
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('All')
  const filtered = useMemo(() => books.filter(book => {
    const matches = `${book.title} ${book.author} ${book.category}`.toLowerCase().includes(search.toLowerCase())
    return matches && (category === 'All' || book.category === category)
  }), [search, category])
  const categories = ['All', ...new Set(books.map(book => book.category))]
  return <>
    <div className="page-heading"><span className="eyebrow">THE BOOKSHELF</span><h1>Explore the collection</h1><p>Find a story, discover an idea, or meet a new favourite author.</p></div>
    <div className="catalogue-tools"><label className="search-box"><span>⌕</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by title, author or genre..." /></label><select value={category} onChange={e => setCategory(e.target.value)} aria-label="Filter by category">{categories.map(item => <option key={item}>{item}</option>)}</select><span className="result-count">{filtered.length} books</span></div>
    <div className="book-grid">{filtered.length ? filtered.map(book => <BookCard key={book.id} book={book} onAdd={onAdd} />) : <div className="empty-results"><h3>No books found</h3><p>Try a different title or category.</p></div>}</div>
  </>
}
