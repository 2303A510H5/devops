import { Link } from 'react-router-dom'
import { courses } from '../data.js'

export default function CourseList() {
  return <><div className="page-title-row"><div><span className="eyebrow">ACADEMIC CATALOGUE</span><h1>Courses</h1><p className="muted">Explore the courses offered across departments.</p></div><span className="count-pill">{courses.length} courses</span></div><div className="course-grid">{courses.map((course, index) => <article className="course-card" key={course.id}><div className={`course-icon course-${index}`}>▤</div><span className="course-code">{course.id}</span><h3>{course.name}</h3><p>{course.department}</p><div className="course-meta"><span>{course.credits} credits</span><span>{course.semester}</span></div><Link to={`/courses/${course.id}`} className="view-link">View course details →</Link></article>)}</div></>
}
