const express = require("express");
const cors = require("cors");

const app = express();
const PORT = Number(process.env.PORT) || 5000;

app.disable("x-powered-by");
app.use(cors());
app.use(express.json({ limit: "1mb" }));

let products = [
  { id: 1, name: "Laptop", price: 60000, category: "Electronics" },
  { id: 2, name: "Headphones", price: 2000, category: "Electronics" }
];
let nextProductId = 3;

app.get("/health", (_req, res) => {
  res.status(200).json({ status: "UP", service: "Online Shopping API" });
});

app.get("/api/products", (_req, res) => {
  res.json(products);
});

app.get("/api/products/:id", (req, res) => {
  const product = products.find(item => item.id === Number(req.params.id));
  if (!product) return res.status(404).json({ error: "Product not found" });
  res.json(product);
});

app.post("/api/products", (req, res) => {
  const { name, price, category } = req.body || {};
  if (typeof name !== "string" || !name.trim() ||
      typeof category !== "string" || !category.trim() ||
      !Number.isFinite(Number(price)) || Number(price) < 0) {
    return res.status(400).json({
      error: "name, category, and a non-negative numeric price are required"
    });
  }

  const product = {
    id: nextProductId++,
    name: name.trim(),
    price: Number(price),
    category: category.trim()
  };
  products.push(product);
  res.status(201).json(product);
});

app.put("/api/products/:id", (req, res) => {
  const product = products.find(item => item.id === Number(req.params.id));
  if (!product) return res.status(404).json({ error: "Product not found" });

  const { name, price, category } = req.body || {};
  if (name !== undefined && (typeof name !== "string" || !name.trim())) {
    return res.status(400).json({ error: "name must be a non-empty string" });
  }
  if (price !== undefined && (!Number.isFinite(Number(price)) || Number(price) < 0)) {
    return res.status(400).json({ error: "price must be a non-negative number" });
  }
  if (category !== undefined && (typeof category !== "string" || !category.trim())) {
    return res.status(400).json({ error: "category must be a non-empty string" });
  }

  if (name !== undefined) product.name = name.trim();
  if (price !== undefined) product.price = Number(price);
  if (category !== undefined) product.category = category.trim();

  res.json(product);
});

app.delete("/api/products/:id", (req, res) => {
  const productIndex = products.findIndex(item => item.id === Number(req.params.id));
  if (productIndex === -1) {
    return res.status(404).json({ error: "Product not found" });
  }
  const [deletedProduct] = products.splice(productIndex, 1);
  res.json({ message: "Product deleted successfully", product: deletedProduct });
});

app.use((req, res) => {
  res.status(404).json({ error: "Route not found", path: req.originalUrl });
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Online Shopping API running on port ${PORT}`);
});
