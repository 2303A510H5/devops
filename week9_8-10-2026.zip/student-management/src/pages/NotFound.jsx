import { Link } from 'react-router-dom'
export default function NotFound() {
  return <section className="panel not-found"><strong>404</strong><h1>Page not found</h1><p className="muted">The page you are looking for doesn't exist or may have moved.</p><Link className="btn btn-primary" to="/">Go to Home</Link></section>
}
