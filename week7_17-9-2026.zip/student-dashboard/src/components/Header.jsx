export default function Header() {
  return <header className="topbar"><div className="container nav-inner"><div className="college-brand"><span className="college-logo">S</span><span><strong>SR University</strong><small>LEARN · LEAD · INSPIRE</small></span></div><div className="header-right"><span className="portal-label">STUDENT PORTAL</span><span className="header-avatar">S</span></div></div></header>
}
