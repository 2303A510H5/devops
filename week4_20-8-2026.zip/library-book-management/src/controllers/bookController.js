const { Op } = require('sequelize');
const Book = require('../models/Book');

const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

exports.createBook = asyncHandler(async (req, res) => {
  const { title, author, isbn, price, availableCopies } = req.body;
  const book = await Book.create({ title, author, isbn, price, availableCopies });
  res.status(201).json({ success: true, message: 'Book created successfully', data: book });
});

exports.getBooks = asyncHandler(async (req, res) => {
  const { author, availability, sort } = req.query;
  const where = {};
  if (author) where.author = { [Op.iLike]: `%${author}%` };
  if (availability === 'available') where.availableCopies = { [Op.gt]: 0 };
  if (availability === 'unavailable') where.availableCopies = 0;

  const order = sort === 'desc' ? [['title', 'DESC']] : [['title', 'ASC']];
  const books = await Book.findAll({ where, order });
  res.status(200).json({ success: true, count: books.length, data: books });
});

exports.getBookById = asyncHandler(async (req, res) => {
  const book = await Book.findByPk(req.params.id);
  if (!book) return res.status(404).json({ success: false, message: 'Book not found' });
  res.json({ success: true, data: book });
});

exports.updateBook = asyncHandler(async (req, res) => {
  const book = await Book.findByPk(req.params.id);
  if (!book) return res.status(404).json({ success: false, message: 'Book not found' });
  await book.update(req.body);
  res.json({ success: true, message: 'Book updated successfully', data: book });
});

exports.deleteBook = asyncHandler(async (req, res) => {
  const book = await Book.findByPk(req.params.id);
  if (!book) return res.status(404).json({ success: false, message: 'Book not found' });
  await book.destroy();
  res.json({ success: true, message: 'Book deleted successfully' });
});
