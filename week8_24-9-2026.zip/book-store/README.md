# Online Book Store

A responsive React single-page book store demonstrating React Router, dynamic route parameters, and functional-component lifecycle behavior.

## Features
- Home, Books, Book Details, Cart, About and 404 pages
- Client-side navigation with `NavLink` and `Link`
- Dynamic book routes using `/books/:id` and `useParams()`
- Book details loaded with `useEffect()` and a simulated delay
- Loading state, invalid-book message and effect cleanup
- Cart state with `useState()`, Add to Cart buttons and live cart count
- Cart quantity updates, item removal and clear-cart action
- Responsive layout

## Run locally
Install Node.js 18+ and open this folder in VS Code. In the terminal run:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually http://localhost:5173).

## Routes
| URL | Page |
|---|---|
| `/` | Home |
| `/books` | Book catalogue |
| `/books/101` | Book details |
| `/books/:id` | Dynamic book details |
| `/cart` | Shopping cart |
| `/about` | About |
| `*` | 404 Not Found |

## Lifecycle demonstration
- When BookDetails mounts or the route ID changes, `useEffect()` starts a simulated book lookup and shows `Loading book details...`.
- The effect cleanup clears its pending timer and logs a cleanup message.
- Open the browser developer console and navigate between book IDs to observe the effect and cleanup logs.

The sample catalogue is stored in `src/data.js`. No backend or external API is required.
