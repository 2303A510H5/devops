const app = require("./app");
const { initializeDatabase } = require("./db");

const PORT = Number(process.env.PORT) || 5000;

initializeDatabase()
  .then(() => {
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Shopping API listening on port ${PORT}`);
    });
  })
  .catch(err => {
    console.error("Database initialization failed:", err);
    process.exit(1);
  });
