# Week 10 — Online Shopping Application CI Pipeline

![CI](https://github.com/USERNAME/REPOSITORY/actions/workflows/ci.yml/badge.svg)

A sample React + Node.js/Express shopping application with automated frontend and backend checks using GitHub Actions.

## Features
- Product listing and search
- Add, update, and delete products
- Shopping cart with quantity and total calculation
- Express product CRUD API
- Frontend tests with Vitest and React Testing Library
- Backend API tests with Jest and Supertest
- ESLint checks, coverage reports, and Vite production build
- Separate frontend and backend CI jobs

## Project structure
```text
shopping-app/
├── frontend/
├── backend/
└── .github/workflows/ci.yml
```

## Run locally
Open two terminals.

Backend:
```bash
cd backend
npm install
npm test
npm run lint
npm start
```
API: `http://localhost:5000/api/products`

Frontend:
```bash
cd frontend
npm install
npm test
npm run lint
npm run build
npm run dev
```

## CI workflow
GitHub Actions runs separate frontend and backend jobs on pushes and pull requests targeting `main` or `master`. Workflow runs are limited to changes under `frontend/`, `backend/`, or the workflow file.

- Frontend: install → ESLint → Vitest + coverage → Vite build → upload build and coverage artifacts.
- Backend: install → ESLint → Jest/Supertest + coverage → upload coverage artifact.

## Demonstrating failure detection
For a controlled demonstration, temporarily change an expected value in a test (for example, expect the product list to have 99 items). Push the change to a feature branch and open a pull request. The relevant CI job should fail. Revert the incorrect expectation and push again; the tests should pass.

## Branch protection
In GitHub, open **Settings → Branches → Add branch protection rule**, select `main`, enable **Require a pull request before merging**, and require the `Frontend tests and build` and `Backend tests` status checks. Save the rule.

## CI badge
Replace `USERNAME` and `REPOSITORY` in the badge URL above with your GitHub account and repository names.
