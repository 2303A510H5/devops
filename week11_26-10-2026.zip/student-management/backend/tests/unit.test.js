const request = require("supertest");
const app = require("../src/app");

describe("Student API unit-level route checks", () => {
  test("root student collection responds with an array", async () => {
    const response = await request(app).get("/api/students");
    expect(response.statusCode).toBe(200);
    expect(Array.isArray(response.body)).toBe(true);
  });

  test("invalid registration is rejected", async () => {
    const response = await request(app).post("/api/students").send({ name: "Only name" });
    expect(response.statusCode).toBe(400);
  });
});
