import Attendance from './Attendance.jsx'

export default function StudentCard({ student, name, rollNo, onMarkAttendance }) {
  const eligible = student.attendance >= 75
  return <article className={`student-row ${!eligible ? 'low-attendance' : ''}`}>
    <div className="student-name"><span className={`avatar avatar-${student.id % 5}`}>{name.split(' ').map(part => part[0]).slice(0, 2).join('')}</span><div><strong>{name}</strong><small>{student.branch} Department</small></div></div>
    <div className="roll-number">{rollNo}</div>
    <div><span className="branch-badge">{student.branch}</span></div>
    <div className="attendance-cell"><div className="percentage-line"><strong>{student.attendance}%</strong><span>{student.attendance >= 75 ? 'On track' : 'Below 75%'}</span></div><div className="progress-track"><div className={`progress-fill ${!eligible ? 'warning' : ''}`} style={{ width: `${student.attendance}%` }} /></div></div>
    <div><span className={`eligibility ${eligible ? 'eligible' : 'not-eligible'}`}><i></i>{eligible ? 'Eligible' : 'Not Eligible'}</span></div>
    <Attendance status={student.today} onPresent={() => onMarkAttendance(student.id, 'Present')} onAbsent={() => onMarkAttendance(student.id, 'Absent')} />
  </article>
}
