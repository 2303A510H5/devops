import { useState } from 'react'
import Header from './components/Header.jsx'
import StudentProfile from './components/StudentProfile.jsx'
import SubjectList from './components/SubjectList.jsx'
import Attendance from './components/Attendance.jsx'
import ExamDetails from './components/ExamDetails.jsx'
import Footer from './components/Footer.jsx'
import StudentCard from './components/StudentCard.jsx'
import { students } from './data.js'

export default function App() {
  const [selectedStudent, setSelectedStudent] = useState(students[0])

  return <div className="app-shell">
    <Header />
    <main className="container main-content">
      <section className="welcome-row">
        <div><span className="eyebrow">STUDENT PORTAL · ACADEMIC YEAR 2026–27</span><h1>Student Management Dashboard</h1><p>Welcome back! Here's your academic overview and latest updates.</p></div>
        <div className="welcome-date"><span>ACADEMIC SESSION</span><strong>2026 – 2027</strong><small>Semester in progress</small></div>
      </section>

      <section className="student-switcher">
        <div className="section-title"><div><span className="eyebrow">STUDENT DIRECTORY</span><h2>Choose a student profile</h2></div><span className="student-count">{students.length} sample students</span></div>
        <div className="student-cards">{students.map(student => <StudentCard key={student.id} student={student} selected={selectedStudent.id === student.id} onViewProfile={() => setSelectedStudent(student)} />)}</div>
      </section>

      <div className="dashboard-grid">
        <div className="main-column">
          <StudentProfile student={selectedStudent} />
          <SubjectList subjects={selectedStudent.subjects} />
        </div>
        <aside className="side-column">
          <Attendance percentage={selectedStudent.attendance} />
          <ExamDetails exams={selectedStudent.exams} semester={selectedStudent.semester} />
        </aside>
      </div>
    </main>
    <Footer />
  </div>
}
