import { fireEvent, render, screen, within } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { ShoppingApp } from "../components/ShoppingApp";

describe("Shopping application", () => {
  it("renders the product catalogue", () => {
    render(<ShoppingApp />);
    expect(screen.getByRole("heading", { name: "Online Shopping" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Laptop" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Headphones" })).toBeInTheDocument();
  });

  it("filters products using the search input", () => {
    render(<ShoppingApp />);
    fireEvent.change(screen.getByRole("textbox", { name: "Search products" }), {
      target: { value: "laptop" }
    });
    expect(screen.getByRole("heading", { name: "Laptop" })).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "Headphones" })).not.toBeInTheDocument();
  });

  it("adds a product to the cart and calculates its total", () => {
    render(<ShoppingApp />);
    const laptopCard = screen.getByRole("heading", { name: "Laptop" }).closest("article");
    fireEvent.click(within(laptopCard).getByRole("button", { name: "Add to cart" }));
    expect(screen.getByRole("heading", { name: "Shopping cart (1)" })).toBeInTheDocument();
    expect(screen.getByText(/Cart total: ₹60,000/)).toBeInTheDocument();
  });

  it("adds a new product to the catalogue", () => {
    render(<ShoppingApp />);
    fireEvent.change(screen.getByRole("textbox", { name: "New product name" }), {
      target: { value: "Keyboard" }
    });
    fireEvent.change(screen.getByRole("spinbutton", { name: "New product price" }), {
      target: { value: "1500" }
    });
    fireEvent.click(screen.getByRole("button", { name: "Add product" }));
    expect(screen.getByRole("heading", { name: "Keyboard" })).toBeInTheDocument();
  });
});
