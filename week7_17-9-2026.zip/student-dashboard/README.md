# Student Management Dashboard

A responsive React + Vite dashboard demonstrating reusable components, props, arrays, and conditional rendering.

## Features
- College header and Student Management Dashboard heading
- Student profile with name, roll number, branch and year
- Reusable StudentCard component with a View Profile button
- Switch between multiple sample students
- Subject list rendered using an array and `map()`
- Attendance percentage with Eligible / Not Eligible status (75% threshold)
- Examination information with upcoming exam and timetable
- Responsive dashboard styling

## Run locally
Install Node.js 18+ and open this folder in VS Code. In the terminal run:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually http://localhost:5173).

## Project structure
- `src/App.jsx` — dashboard layout and selected-student state
- `src/data.js` — sample student, subject and examination data
- `src/components/` — Header, StudentProfile, StudentCard, SubjectList, Attendance, ExamDetails and Footer
- `src/styles.css` — responsive dashboard styling

## React concepts demonstrated
- Props pass student, subject, attendance and exam information to reusable child components.
- `map()` renders multiple student cards and subjects.
- `useState()` manages which student profile is currently selected.
- Conditional rendering displays attendance eligibility based on a 75% minimum.
