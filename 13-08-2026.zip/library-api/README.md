# Library Book Management REST API

A Node.js and Express project implementing CRUD operations for library books.

## 1. Setup

Requirements: Node.js 18+ and Postman.

```bash
npm install
npm run dev
```

The server starts at `http://localhost:5000`. For normal startup without auto-reload, use `npm start`.

## 2. Project structure

```text
library-api/
├── routes/
│   └── books.js
├── server.js
├── package.json
├── .gitignore
└── README.md
```

## 3. API endpoints

Base URL: `http://localhost:5000`

| Method | Endpoint | Description | Success status |
|---|---|---|---|
| GET | `/books` | Get all books | 200 OK |
| GET | `/books/:id` | Get one book by ID | 200 OK |
| POST | `/books` | Add a book | 201 Created |
| PUT | `/books/:id` | Update a book | 200 OK |
| DELETE | `/books/:id` | Delete a book | 200 OK |

### Sample POST body
Choose Body → raw → JSON in Postman:

```json
{
  "title": "Clean Code",
  "author": "Robert C. Martin",
  "isbn": "9780132350884",
  "available": true
}
```

### Sample PUT body
```json
{
  "title": "Clean Code - Updated Edition",
  "available": false
}
```

## 4. Postman testing

1. Start the server with `npm run dev`.
2. Open Postman and create a collection named `Library Book API`.
3. Send `GET http://localhost:5000/books`.
4. Send `GET http://localhost:5000/books/1`.
5. Send `POST http://localhost:5000/books` with the sample JSON body.
6. Send `PUT http://localhost:5000/books/1` with the update JSON body.
7. Send `DELETE http://localhost:5000/books/1`.

For POST and PUT, set the header `Content-Type: application/json`.

## 5. Expected error responses

- `400 Bad Request`: invalid ID, invalid JSON, or validation errors.
- `404 Not Found`: book ID does not exist.
- `409 Conflict`: ISBN is already used.
- `500 Internal Server Error`: unexpected server-side error.

Example missing-book response:
```json
{
  "success": false,
  "message": "Book not found or unavailable in the library"
}
```

## 6. Note about storage

This starter assignment stores records in an in-memory JavaScript array. New, updated, or deleted records remain while the server is running, but reset to the sample data after a restart. A database can be integrated in a later version.
