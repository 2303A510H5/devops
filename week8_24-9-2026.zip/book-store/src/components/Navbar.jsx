import { NavLink } from 'react-router-dom'

export default function Navbar({ cartCount }) {
  const links = [['/', 'Home'], ['/books', 'Books'], ['/about', 'About']]
  return <header className="topbar"><div className="container nav-inner">
    <NavLink to="/" className="brand"><span className="brand-mark">R</span><span><strong>the reading<span>room.</span></strong><small>BOOKS FOR EVERY CHAPTER</small></span></NavLink>
    <nav aria-label="Main navigation">{links.map(([to, label]) => <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>{label}</NavLink>)}<NavLink to="/cart" className={({ isActive }) => isActive ? 'nav-link cart-nav active' : 'nav-link cart-nav'}>Cart <span>{cartCount}</span></NavLink></nav>
  </div></header>
}
