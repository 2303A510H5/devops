import { Link, useNavigate, useParams } from 'react-router-dom'
import { courses } from '../data.js'

export default function CourseDetails() {
  const { id } = useParams()
  const navigate = useNavigate()
  const course = courses.find(item => item.id === id)
  return <><button className="back-button" onClick={() => navigate(-1)}>← Back</button><div className="page-title-row"><div><span className="eyebrow">COURSE INFORMATION</span><h1>Course Details</h1></div></div>{course ? <section className="panel profile-panel"><span className="course-code">{course.id}</span><h2>{course.name}</h2><p className="muted">{course.description}</p><div className="detail-grid"><div><small>COURSE ID</small><strong>{course.id}</strong></div><div><small>DEPARTMENT</small><strong>{course.department}</strong></div><div><small>CREDITS</small><strong>{course.credits}</strong></div><div><small>SEMESTER</small><strong>{course.semester}</strong></div></div><Link className="btn btn-primary" to="/courses">← Back to courses</Link></section> : <div className="panel error-state"><span>!</span><h2>Course not found</h2><p>No course exists with ID {id}.</p><Link className="btn btn-primary" to="/courses">Return to Courses</Link></div>}</>
}
