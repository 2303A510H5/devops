import { useMemo, useState } from "react";

const initialProducts = [
  { id: 1, name: "Laptop", price: 60000, category: "Electronics" },
  { id: 2, name: "Headphones", price: 2000, category: "Electronics" },
  { id: 3, name: "Coffee Maker", price: 3500, category: "Home" }
];

export function ShoppingApp() {
  const [products, setProducts] = useState(initialProducts);
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState([]);
  const [newName, setNewName] = useState("");
  const [newPrice, setNewPrice] = useState("");

  const filteredProducts = useMemo(
    () => products.filter(product =>
      product.name.toLowerCase().includes(search.trim().toLowerCase())
    ),
    [products, search]
  );

  function addToCart(product) {
    setCart(current => {
      const existing = current.find(item => item.id === product.id);
      if (existing) {
        return current.map(item =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...current, { ...product, quantity: 1 }];
    });
  }

  function addProduct(event) {
    event.preventDefault();
    const price = Number(newPrice);
    if (!newName.trim() || !Number.isFinite(price) || price <= 0) return;
    setProducts(current => [
      ...current,
      { id: Math.max(0, ...current.map(item => item.id)) + 1, name: newName.trim(), price, category: "General" }
    ]);
    setNewName("");
    setNewPrice("");
  }

  function updateProduct(product) {
    const updatedName = window.prompt("Enter updated product name:", product.name);
    if (updatedName?.trim()) {
      setProducts(current => current.map(item =>
        item.id === product.id ? { ...item, name: updatedName.trim() } : item
      ));
    }
  }

  function deleteProduct(id) {
    setProducts(current => current.filter(product => product.id !== id));
    setCart(current => current.filter(item => item.id !== id));
  }

  return (
    <main className="container">
      <header>
        <p className="eyebrow">DEVOPS CI PROJECT</p>
        <h1>Online Shopping</h1>
        <p>Browse products, manage your catalogue, and add items to your cart.</p>
      </header>

      <section aria-labelledby="products-heading">
        <div className="section-heading">
          <h2 id="products-heading">Products</h2>
          <label>
            <span className="sr-only">Search products</span>
            <input
              aria-label="Search products"
              placeholder="Search products..."
              value={search}
              onChange={event => setSearch(event.target.value)}
            />
          </label>
        </div>

        <form className="add-form" onSubmit={addProduct}>
          <input aria-label="New product name" placeholder="Product name" value={newName} onChange={e => setNewName(e.target.value)} />
          <input aria-label="New product price" placeholder="Price" type="number" min="1" value={newPrice} onChange={e => setNewPrice(e.target.value)} />
          <button type="submit">Add product</button>
        </form>

        <div className="products">
          {filteredProducts.map(product => (
            <article className="product" key={product.id}>
              <div>
                <h3>{product.name}</h3>
                <p>{product.category}</p>
                <strong>₹{product.price.toLocaleString("en-IN")}</strong>
              </div>
              <div className="actions">
                <button onClick={() => addToCart(product)}>Add to cart</button>
                <button className="secondary" onClick={() => updateProduct(product)}>Edit</button>
                <button className="danger" onClick={() => deleteProduct(product.id)}>Delete</button>
              </div>
            </article>
          ))}
          {filteredProducts.length === 0 && <p role="status">No products found.</p>}
        </div>
      </section>

      <section aria-labelledby="cart-heading" className="cart">
        <h2 id="cart-heading">Shopping cart ({cart.reduce((sum, item) => sum + item.quantity, 0)})</h2>
        {cart.length === 0 ? <p>Your cart is empty.</p> : (
          <>
            {cart.map(item => (
              <p key={item.id}>{item.name} × {item.quantity} — ₹{(item.price * item.quantity).toLocaleString("en-IN")}</p>
            ))}
            <strong>Cart total: ₹{cart.reduce((sum, item) => sum + item.price * item.quantity, 0).toLocaleString("en-IN")}</strong>
          </>
        )}
      </section>
    </main>
  );
}
