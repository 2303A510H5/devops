import { useMemo, useState } from 'react'
import Header from './components/Header.jsx'
import StudentList from './components/StudentList.jsx'
import Summary from './components/Summary.jsx'
import { initialStudents } from './data.js'

export default function App() {
  const [students, setStudents] = useState(initialStudents)
  const [search, setSearch] = useState('')

  const markAttendance = (id, status) => {
    setStudents(current => current.map(student => {
      if (student.id !== id) return student
      if (student.today === status) return student
      const adjusted = student.today === null
        ? student.attendance + (status === 'Present' ? 1 : -1)
        : student.attendance + (status === 'Present' ? 2 : -2)
      return { ...student, attendance: Math.max(0, Math.min(100, adjusted)), today: status }
    }))
  }

  const resetAttendance = () => setStudents(initialStudents.map(student => ({ ...student, today: null })))

  const filteredStudents = useMemo(() => students.filter(student =>
    `${student.name} ${student.rollNo} ${student.branch}`.toLowerCase().includes(search.toLowerCase())
  ), [students, search])

  const present = students.filter(student => student.today === 'Present').length
  const absent = students.filter(student => student.today === 'Absent').length
  const pending = students.length - present - absent
  const average = students.length ? Math.round(students.reduce((sum, student) => sum + student.attendance, 0) / students.length) : 0
  const eligible = students.filter(student => student.attendance >= 75).length

  return <div className="app-shell">
    <Header />
    <main className="container main-content">
      <section className="welcome">
        <div><span className="eyebrow">FACULTY WORKSPACE · 2026</span><h1>Student Attendance<br /><span>Management System</span></h1><p>Track daily attendance, monitor student progress and keep your class on track.</p></div>
        <div className="welcome-art" aria-hidden="true"><div className="art-circle">✓</div><span>CLASS<br />RECORDS</span></div>
      </section>
      <Summary total={students.length} present={present} absent={absent} pending={pending} average={average} eligible={eligible} />
      <section className="list-section">
        <div className="section-heading"><div><span className="eyebrow">CLASS REGISTER</span><h2>Student attendance</h2><p>Mark each student's attendance for today.</p></div><button className="reset-button" onClick={resetAttendance}>↻ Reset Attendance</button></div>
        <div className="list-toolbar"><label className="search-box"><span>⌕</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search name, roll number or branch..." /></label><span className="showing-count">Showing {filteredStudents.length} of {students.length} students</span></div>
        <StudentList students={filteredStudents} onMarkAttendance={markAttendance} />
      </section>
      <div className="footnote"><span>ⓘ</span> Attendance eligibility is calculated using the 75% minimum requirement. Marking attendance updates the sample percentage for demonstration.</div>
    </main>
    <footer className="footer">© 2026 Student Attendance Management System <span>Faculty dashboard · Attendance overview</span></footer>
  </div>
}
