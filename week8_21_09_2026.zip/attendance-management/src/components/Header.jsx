export default function Header() {
  return <header className="topbar"><div className="container nav-inner"><div className="brand"><span className="brand-mark">A</span><span><strong>Attend<span>Ease</span></strong><small>ACADEMIC MANAGEMENT</small></span></div><div className="faculty"><span className="faculty-dot"></span><span>Faculty Dashboard</span><div className="faculty-avatar">F</div></div></div></header>
}
