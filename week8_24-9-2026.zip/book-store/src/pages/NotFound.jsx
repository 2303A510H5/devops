import { Link } from 'react-router-dom'
export default function NotFound() {
  return <section className="not-found-page"><strong>404</strong><h1>This page isn't on our shelf.</h1><p>The page you're looking for may have moved or doesn't exist.</p><Link to="/" className="primary-button">Back to Home →</Link></section>
}
