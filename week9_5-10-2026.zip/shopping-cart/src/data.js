export const products = [
  { id: 'P101', name: 'Laptop', category: 'Electronics', price: 60000, description: 'Powerful performance for work, study and creativity.', icon: '💻', tone: 'lavender', tag: 'Popular' },
  { id: 'P102', name: 'Headphones', category: 'Electronics', price: 2000, description: 'Immersive sound with a comfortable everyday fit.', icon: '🎧', tone: 'peach', tag: 'Best seller' },
  { id: 'P103', name: 'Backpack', category: 'Accessories', price: 1500, description: 'A practical everyday backpack with spacious storage.', icon: '🎒', tone: 'mint', tag: '' },
  { id: 'P104', name: 'Smart Watch', category: 'Electronics', price: 3500, description: 'Track your day, activity and everyday notifications.', icon: '⌚', tone: 'blue', tag: 'New' },
  { id: 'P105', name: 'Running Shoes', category: 'Fashion', price: 2800, description: 'Lightweight comfort for active days and long walks.', icon: '👟', tone: 'yellow', tag: '' },
  { id: 'P106', name: 'Water Bottle', category: 'Accessories', price: 650, description: 'Reusable insulated bottle for daily hydration.', icon: '🧴', tone: 'rose', tag: '' }
]
