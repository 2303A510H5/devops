const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Book = sequelize.define('Book', {
  bookId: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
    field: 'book_id'
  },
  title: {
    type: DataTypes.STRING(200),
    allowNull: false,
    validate: { notEmpty: { msg: 'Title is required' } }
  },
  author: {
    type: DataTypes.STRING(150),
    allowNull: false,
    validate: { notEmpty: { msg: 'Author is required' } }
  },
  isbn: {
    type: DataTypes.STRING(20),
    allowNull: false,
    unique: { name: 'books_isbn_unique', msg: 'ISBN already exists' },
    validate: {
      notEmpty: { msg: 'ISBN is required' },
      is: { args: /^[0-9Xx-]{10,17}$/, msg: 'ISBN must contain 10–17 digits, X, or hyphens' }
    }
  },
  price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    validate: { min: { args: [0], msg: 'Price cannot be negative' } }
  },
  availableCopies: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 0,
    field: 'available_copies',
    validate: { min: { args: [0], msg: 'Available copies cannot be negative' }, isInt: true }
  }
}, {
  tableName: 'books',
  timestamps: true,
  underscored: true
});

module.exports = Book;
