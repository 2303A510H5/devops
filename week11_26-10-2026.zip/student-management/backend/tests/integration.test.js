const request = require("supertest");
const app = require("../src/app");
const db = require("../src/db");

describe("Student API integration workflow", () => {
  let createdStudent;

  beforeAll(async () => {
    await db.initializeDatabase();
  });

  afterAll(async () => {
    await db.closeDatabase();
  });

  test("registers a student and retrieves the student list", async () => {
    const response = await request(app)
      .post("/api/students")
      .send({ name: "Rahul", rollNo: "CSE101-TEST", branch: "CSE" });

    expect(response.statusCode).toBe(201);
    expect(response.body.rollNo).toBe("CSE101-TEST");
    createdStudent = response.body;

    const listResponse = await request(app).get("/api/students");
    expect(listResponse.statusCode).toBe(200);
    expect(listResponse.body.some(student => student.rollNo === "CSE101-TEST")).toBe(true);
  });

  test("retrieves the created student by ID", async () => {
    const response = await request(app).get(`/api/students/${createdStudent.id}`);
    expect(response.statusCode).toBe(200);
    expect(response.body.name).toBe("Rahul");
  });

  test("updates the student", async () => {
    const response = await request(app)
      .put(`/api/students/${createdStudent.id}`)
      .send({ name: "Rahul Updated", rollNo: "CSE101-TEST", branch: "CSE" });

    expect(response.statusCode).toBe(200);
    expect(response.body.name).toBe("Rahul Updated");
  });

  test("rejects invalid student data", async () => {
    const response = await request(app)
      .post("/api/students")
      .send({ name: "", rollNo: "BAD-TEST" });

    expect(response.statusCode).toBe(400);
  });

  test("deletes the student and verifies it cannot be retrieved", async () => {
    const deleteResponse = await request(app).delete(`/api/students/${createdStudent.id}`);
    expect(deleteResponse.statusCode).toBe(200);

    const getResponse = await request(app).get(`/api/students/${createdStudent.id}`);
    expect(getResponse.statusCode).toBe(404);
  });
});
