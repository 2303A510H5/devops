export default function Header({ itemCount }) {
  return <header className="topbar"><div className="container nav-inner"><a href="#" className="brand" onClick={e => e.preventDefault()}><span className="brand-icon">S</span><span><strong>Shop<span>Ease</span></strong><small>SHOP SMARTER</small></span></a><div className="header-right"><span className="secure-label">✦ Easy shopping, happy living</span><div className="cart-count">♧ <b>{itemCount}</b></div></div></div></header>
}
