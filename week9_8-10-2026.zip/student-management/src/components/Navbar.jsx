import { NavLink } from 'react-router-dom'

const links = [
  ['/', 'Home'],
  ['/students', 'Students'],
  ['/courses', 'Courses'],
  ['/about', 'About']
]

export default function Navbar() {
  return (
    <header className="topbar">
      <div className="container nav-inner">
        <NavLink to="/" className="brand">
          <span className="brand-mark">C</span>
          <span><strong>Campus<span className="brand-accent">Hub</span></strong><small>STUDENT PORTAL</small></span>
        </NavLink>
        <nav aria-label="Main navigation">
          {links.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
              {label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  )
}
