import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { getStudent } from "../services/studentApi";

export default function StudentDetails() {
  const { id } = useParams();
  const [student, setStudent] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    getStudent(id)
      .then(data => { if (active) setStudent(data); })
      .catch(err => { if (active) setError(err.message); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [id]);

  return (
    <section className="details-panel">
      <Link to="/" className="back-link">← Back to dashboard</Link>
      {loading && <p className="info-message">Loading student details...</p>}
      {error && <p className="error-message" role="alert">{error}</p>}
      {student && (
        <>
          <p className="eyebrow">STUDENT PROFILE</p>
          <h1>{student.name}</h1>
          <div className="detail-grid">
            <div><span>Roll number</span><strong>{student.rollNo}</strong></div>
            <div><span>Branch</span><strong>{student.branch}</strong></div>
            <div><span>Student ID</span><strong>#{student.id}</strong></div>
          </div>
        </>
      )}
    </section>
  );
}
