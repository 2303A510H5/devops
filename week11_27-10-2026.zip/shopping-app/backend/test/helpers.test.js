const test = require("node:test");
const assert = require("node:assert/strict");
const { calculateTotal } = require("../src/helpers");

test("calculateTotal multiplies item price by quantity and sums items", () => {
  const total = calculateTotal([
    { price: 60000, quantity: 2 },
    { price: 2000, quantity: 1 }
  ]);
  assert.equal(total, 122000);
});

test("calculateTotal returns zero for an empty cart", () => {
  assert.equal(calculateTotal([]), 0);
});
