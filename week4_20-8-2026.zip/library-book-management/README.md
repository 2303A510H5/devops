# Library Book Management System

REST API built with Node.js, Express, PostgreSQL and Sequelize ORM.

## 1. Requirements
- Node.js 18+
- PostgreSQL and pgAdmin
- Postman (for API testing)

## 2. Create the database
In pgAdmin, connect to your PostgreSQL server, right-click **Databases → Create → Database**, and name it `library_db`.

Alternatively, run this SQL in Query Tool:
```sql
CREATE DATABASE library_db;
```
If the database already exists, do not run the command again.

## 3. Configure the project
Open this folder in VS Code and run:
```bash
npm install
```
Copy `.env.example` to a new file named `.env`, then enter your PostgreSQL username and password:
```env
PORT=5000
DB_HOST=localhost
DB_PORT=5432
DB_NAME=library_db
DB_USER=postgres
DB_PASSWORD=your_actual_password
DB_DIALECT=postgres
```
Do not share or commit your `.env` file.

## 4. Start the API
```bash
npm run dev
```
or:
```bash
npm start
```
On startup, Sequelize authenticates the connection and synchronizes the `books` table. The API is available at `http://localhost:5000`.

## 5. Book model
- `bookId`: auto-incrementing primary key
- `title`: required string
- `author`: required string
- `isbn`: required, unique string
- `price`: required non-negative decimal
- `availableCopies`: required non-negative integer (defaults to 0)

## 6. API endpoints

Base URL: `http://localhost:5000/api/books`

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/books` | Create a book |
| GET | `/api/books` | Retrieve all books |
| GET | `/api/books/:id` | Retrieve one book |
| PUT | `/api/books/:id` | Update a book |
| DELETE | `/api/books/:id` | Delete a book |

### Create book – POST `/api/books`
Set Body → raw → JSON:
```json
{
  "title": "The Alchemist",
  "author": "Paulo Coelho",
  "isbn": "9780061122415",
  "price": 399.00,
  "availableCopies": 8
}
```

### Get all books – GET `/api/books`

### Get one book – GET `/api/books/1`

### Update book – PUT `/api/books/1`
```json
{
  "price": 450.00,
  "availableCopies": 10
}
```

### Delete book – DELETE `/api/books/1`

## 7. Bonus search, filter and sorting
- Search author: `GET /api/books?author=paulo`
- Available books: `GET /api/books?availability=available`
- Unavailable books: `GET /api/books?availability=unavailable`
- Sort title A–Z: `GET /api/books?sort=asc`
- Sort title Z–A: `GET /api/books?sort=desc`
- Combine: `GET /api/books?author=paulo&availability=available&sort=asc`

## 8. Postman testing
For each request, choose the HTTP method, enter the URL, and select Body → raw → JSON for POST and PUT requests. Expected status codes:
- Create: `201 Created`
- Successful reads/updates/deletes: `200 OK`
- Invalid input: `400 Bad Request`
- Duplicate ISBN: `409 Conflict`
- Missing book or route: `404 Not Found`
- Database unavailable during startup: the server prints a clear connection error and exits.

## 9. Troubleshooting
- Ensure the PostgreSQL service is running.
- Confirm `library_db` exists.
- Verify `DB_USER`, `DB_PASSWORD`, host and port in `.env`.
- PostgreSQL's default port is `5432`.
- If you change the model, restart the server. `sequelize.sync()` creates missing tables but does not perform destructive schema migrations.
