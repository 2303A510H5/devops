# Online Shopping Product API Testing and Documentation

A ready-to-run Node.js/Express Product REST API, plus an importable Postman collection and local environment.

## Project setup
Requirements: Node.js 18+ and Postman.

```bash
npm install
npm run dev
```

Server URL: `http://localhost:5000`

The sample products are stored in `src/data/products.json`. The API writes create/update/delete changes back to this file, so data persists between server restarts.

## Endpoints

| Method | URL | Purpose | Success response |
|---|---|---|---|
| GET | `/products` | Retrieve all products | 200 OK |
| GET | `/products/:id` | Retrieve product by ID | 200 OK |
| POST | `/products` | Create product | 201 Created |
| PUT | `/products/:id` | Update product fields | 200 OK |
| DELETE | `/products/:id` | Delete product | 200 OK |

### Product JSON
```json
{
  "name": "Bluetooth Speaker",
  "description": "Portable wireless speaker",
  "price": 1999,
  "category": "Electronics",
  "stock": 30
}
```
Required fields for POST: `name`, `description`, `price`, `category`, `stock`.
For PUT, send one or more fields to update. Price must be a non-negative number; stock must be a non-negative integer.

## Postman collection and environment
1. Open Postman.
2. Select **Import** and import `postman/Shopping_Product_API.postman_collection.json`.
3. Import `postman/Shopping_Product_API.postman_environment.json`.
4. Select the **Shopping API - Local** environment.
5. Start the server, then run the requests in order:
   - GET all products
   - GET product by ID
   - POST create product
   - PUT update product
   - DELETE product
   - Negative test requests
6. The POST test stores the returned ID in `createdProductId`, which is used by the PUT and DELETE requests.
7. Each request includes Postman test assertions for expected status codes and response content. Open the **Test Results** tab after sending a request.

## Headers and parameters
- POST and PUT: `Content-Type: application/json`
- GET all: no required query parameters.
- GET by ID, PUT, DELETE: path parameter `id` (positive integer).
- Base URL is configured as the `baseUrl` environment variable.

## Expected error responses
- Invalid ID format: `400 Bad Request`
- Invalid/missing fields: `400 Bad Request` with an `errors` array
- Product does not exist: `404 Not Found`
- Unknown API route: `404 Not Found`
- Unexpected server error: `500 Internal Server Error`

## Saving responses and exporting
Postman stores each response in the request's response panel. To retain a response as a named example, open the request after a successful response and choose **Save Response → Save as example** (Postman UI wording may vary). To export, use the collection's three-dot menu → Export → Collection v2.1 JSON. The included collection is already provided in JSON format.
