import { useEffect, useState } from "react";

const emptyForm = { name: "", rollNo: "", branch: "" };

export default function StudentForm({ onSubmit, editingStudent, onCancel }) {
  const [form, setForm] = useState(emptyForm);

  useEffect(() => {
    setForm(editingStudent
      ? { name: editingStudent.name, rollNo: editingStudent.rollNo, branch: editingStudent.branch }
      : emptyForm);
  }, [editingStudent]);

  function handleChange(event) {
    setForm(current => ({ ...current, [event.target.name]: event.target.value }));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    const success = await onSubmit(form);
    if (success) setForm(emptyForm);
  }

  return (
    <form className="student-form" onSubmit={handleSubmit}>
      <div className="form-grid">
        <label>Student name
          <input name="name" value={form.name} onChange={handleChange} placeholder="Enter full name" required maxLength="100" />
        </label>
        <label>Roll number
          <input name="rollNo" value={form.rollNo} onChange={handleChange} placeholder="e.g. CSE103" required maxLength="30" />
        </label>
        <label>Branch
          <select name="branch" value={form.branch} onChange={handleChange} required>
            <option value="">Select branch</option>
            <option value="CSE">Computer Science (CSE)</option>
            <option value="ECE">Electronics (ECE)</option>
            <option value="EEE">Electrical (EEE)</option>
            <option value="MECH">Mechanical</option>
            <option value="CIVIL">Civil</option>
            <option value="IT">Information Technology</option>
          </select>
        </label>
      </div>
      <div className="form-actions">
        <button className="primary-button" type="submit">{editingStudent ? "Save changes" : "Add student"}</button>
        {editingStudent && <button className="cancel-button" type="button" onClick={onCancel}>Cancel</button>}
      </div>
    </form>
  );
}
