import React from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

function App() {
  return (
    <main>
      <h1>College Student Management</h1>
      <p>Manage student registration and records through the Student REST API.</p>
      <p>API endpoint: <code>http://localhost:5000/api/students</code></p>
    </main>
  );
}

createRoot(document.getElementById("root")).render(<App />);
