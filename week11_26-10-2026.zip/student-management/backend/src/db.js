const { Pool } = require("pg");

const pool = process.env.DATABASE_URL
  ? new Pool({ connectionString: process.env.DATABASE_URL })
  : null;

// PostgreSQL is used in CI. A small in-memory fallback keeps the API easy to run locally.
const memoryStudents = [];
let nextMemoryId = 1;

async function listStudents() {
  if (pool) {
    const result = await pool.query(
      "SELECT id, name, roll_no AS \"rollNo\", branch FROM students ORDER BY id"
    );
    return result.rows;
  }
  return memoryStudents;
}

async function getStudent(id) {
  if (pool) {
    const result = await pool.query(
      'SELECT id, name, roll_no AS "rollNo", branch FROM students WHERE id = $1',
      [id]
    );
    return result.rows[0] || null;
  }
  return memoryStudents.find(student => student.id === Number(id)) || null;
}

async function createStudent({ name, rollNo, branch }) {
  if (pool) {
    const result = await pool.query(
      `INSERT INTO students (name, roll_no, branch)
       VALUES ($1, $2, $3)
       RETURNING id, name, roll_no AS "rollNo", branch`,
      [name, rollNo, branch]
    );
    return result.rows[0];
  }
  const student = { id: nextMemoryId++, name, rollNo, branch };
  memoryStudents.push(student);
  return student;
}

async function updateStudent(id, { name, rollNo, branch }) {
  if (pool) {
    const result = await pool.query(
      `UPDATE students
       SET name = $1, roll_no = $2, branch = $3
       WHERE id = $4
       RETURNING id, name, roll_no AS "rollNo", branch`,
      [name, rollNo, branch, id]
    );
    return result.rows[0] || null;
  }
  const student = await getStudent(id);
  if (!student) return null;
  Object.assign(student, { name, rollNo, branch });
  return student;
}

async function deleteStudent(id) {
  if (pool) {
    const result = await pool.query(
      "DELETE FROM students WHERE id = $1 RETURNING id",
      [id]
    );
    return result.rowCount > 0;
  }
  const index = memoryStudents.findIndex(student => student.id === Number(id));
  if (index === -1) return false;
  memoryStudents.splice(index, 1);
  return true;
}

async function initializeDatabase() {
  if (!pool) return;
  await pool.query(`
    CREATE TABLE IF NOT EXISTS students (
      id SERIAL PRIMARY KEY,
      name VARCHAR(120) NOT NULL,
      roll_no VARCHAR(40) NOT NULL UNIQUE,
      branch VARCHAR(80) NOT NULL
    )
  `);
}

async function closeDatabase() {
  if (pool) await pool.end();
}

module.exports = {
  pool,
  initializeDatabase,
  closeDatabase,
  listStudents,
  getStudent,
  createStudent,
  updateStudent,
  deleteStudent
};
