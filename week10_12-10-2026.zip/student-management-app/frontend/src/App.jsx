import { useEffect, useMemo, useState } from "react";
import { Route, Routes } from "react-router-dom";
import Header from "./components/Header";
import StudentForm from "./components/StudentForm";
import StudentList from "./components/StudentList";
import StudentDetails from "./pages/StudentDetails";
import { createStudent, deleteStudent, getStudents, updateStudent } from "./services/studentApi";

function Dashboard() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [search, setSearch] = useState("");
  const [branchFilter, setBranchFilter] = useState("ALL");
  const [editingStudent, setEditingStudent] = useState(null);

  async function loadStudents() {
    setLoading(true);
    setError("");
    try {
      setStudents(await getStudents());
    } catch (err) {
      setError(err.message || "Unable to load students. Check that the backend is running.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadStudents(); }, []);

  const filteredStudents = useMemo(() => students.filter(student => {
    const matchesSearch = `${student.name} ${student.rollNo}`.toLowerCase().includes(search.toLowerCase());
    const matchesBranch = branchFilter === "ALL" || student.branch === branchFilter;
    return matchesSearch && matchesBranch;
  }), [students, search, branchFilter]);

  async function handleSubmit(form) {
    setNotice("");
    setError("");
    try {
      if (editingStudent) {
        await updateStudent(editingStudent.id, form);
        setNotice("Student details updated successfully.");
        setEditingStudent(null);
      } else {
        await createStudent(form);
        setNotice("Student added successfully.");
      }
      await loadStudents();
      return true;
    } catch (err) {
      setError(err.message);
      return false;
    }
  }

  async function handleDelete(student) {
    const confirmed = window.confirm(`Are you sure you want to delete ${student.name}?`);
    if (!confirmed) return;
    setNotice("");
    setError("");
    try {
      await deleteStudent(student.id);
      setNotice(`${student.name} was deleted successfully.`);
      if (editingStudent?.id === student.id) setEditingStudent(null);
      await loadStudents();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <>
      <div className="hero">
        <div>
          <p className="eyebrow">COLLEGE ADMINISTRATION</p>
          <h1>Student Management</h1>
          <p className="hero-subtitle">Manage student records, all in one place.</p>
        </div>
        <div className="hero-icon" aria-hidden="true">▤</div>
      </div>

      <div className="stats-row">
        <div className="stat-card">
          <span className="stat-icon">♙</span>
          <div><span className="stat-label">Total students</span><strong>{students.length}</strong></div>
        </div>
        <div className="stat-card">
          <span className="stat-icon purple">▦</span>
          <div><span className="stat-label">Branches</span><strong>{new Set(students.map(s => s.branch)).size}</strong></div>
        </div>
      </div>

      <section className="panel">
        <div className="panel-heading">
          <div><p className="eyebrow">STUDENT DIRECTORY</p><h2>All students</h2></div>
          <span className="count-pill">{filteredStudents.length} records</span>
        </div>
        <div className="toolbar">
          <input aria-label="Search students" className="search-input" placeholder="Search by name or roll number..." value={search} onChange={e => setSearch(e.target.value)} />
          <select aria-label="Filter by branch" value={branchFilter} onChange={e => setBranchFilter(e.target.value)}>
            <option value="ALL">All branches</option>
            {["CSE", "ECE", "EEE", "MECH", "CIVIL", "IT"].map(branch => <option key={branch} value={branch}>{branch}</option>)}
          </select>
        </div>
        {notice && <p className="success-message" role="status">{notice}</p>}
        {error && <p className="error-message" role="alert">{error}</p>}
        {loading ? <p className="info-message">Loading student records...</p> : (
          <StudentList students={filteredStudents} onDelete={handleDelete} onEdit={student => { setEditingStudent(student); setNotice(""); }} />
        )}
      </section>

      <section className="panel form-panel">
        <div className="panel-heading">
          <div><p className="eyebrow">{editingStudent ? "EDIT RECORD" : "NEW ENROLLMENT"}</p><h2>{editingStudent ? "Update student" : "Add a student"}</h2></div>
          <span className="form-icon">＋</span>
        </div>
        <StudentForm onSubmit={handleSubmit} editingStudent={editingStudent} onCancel={() => setEditingStudent(null)} />
      </section>
      <footer>CampusConnect · Student Management System</footer>
    </>
  );
}

export default function App() {
  return (
    <div className="app-shell">
      <Header />
      <main className="main-content">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/students/:id" element={<StudentDetails />} />
        </Routes>
      </main>
    </div>
  );
}
