# Week 11 Assessment — Dockerizing Food Delivery Backend

## Overview
A Node.js 20 + Express REST API for a sample food delivery application. It includes restaurant, food, order, and health endpoints and is packaged with a production-oriented Dockerfile.

> **Assessment note:** Restaurant and food records are sample in-memory data. Orders are also stored in memory and are lost when the server/container is recreated. PostgreSQL/MongoDB persistence is an extension task, not implemented in this version.

## Project structure
```text
food-backend/
├── server.js
├── routes/
│   ├── restaurantRoutes.js
│   ├── foodRoutes.js
│   └── orderRoutes.js
├── package.json
├── package-lock.json
├── .dockerignore
├── .env.example
├── Dockerfile
└── README.md
```

## Run locally
Requires Node.js 20 or later.
```bash
npm ci
# Optional: configure PORT and NODE_ENV using your environment
npm start
```
The API runs at `http://localhost:5000` by default.

## Build Docker image
Run from the `food-backend` directory:
```bash
docker build -t food-backend:v1 .
docker images
```

## Create network and run container
```bash
docker network create food-network
docker run -d \
  --restart unless-stopped \
  --network food-network \
  -p 5000:5000 \
  --name food-api \
  -e PORT=5000 \
  -e NODE_ENV=production \
  food-backend:v1
```
If the network already exists, do not create it again. If a container named `food-api` already exists, remove it with `docker rm -f food-api` before running the command again.

## API endpoints
| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Health status |
| GET | `/api/restaurants` | List all restaurants |
| GET | `/api/restaurants/:id` | Get a restaurant by ID |
| GET | `/api/foods` | List all food items |
| GET | `/api/foods/:id` | Get a food item by ID |
| POST | `/api/orders` | Create an order |
| GET | `/api/orders` | List orders |

## Postman testing
Use `http://localhost:5000` as the base URL.

**GET requests**
- `GET http://localhost:5000/health`
- `GET http://localhost:5000/api/restaurants`
- `GET http://localhost:5000/api/restaurants/1`
- `GET http://localhost:5000/api/foods`
- `GET http://localhost:5000/api/foods/101`
- `GET http://localhost:5000/api/orders`

**POST order**
- Method: `POST`
- URL: `http://localhost:5000/api/orders`
- Header: `Content-Type: application/json`
- Body → raw → JSON:
```json
{
  "customerName": "Parimala",
  "items": [
    { "foodId": 101, "quantity": 2 },
    { "foodId": 102, "quantity": 1 }
  ]
}
```
A successful request returns HTTP `201 Created`.

## Container management and monitoring
```bash
docker ps
docker logs food-api
docker inspect food-api
docker stop food-api
docker start food-api
docker ps
```
Check health status:
```bash
docker inspect --format='{{.State.Health.Status}}' food-api
```

## Image versioning
```bash
docker build -t food-backend:v1 .
docker tag food-backend:v1 food-backend:latest
docker images
```

## Stop and clean up
```bash
docker rm -f food-api
docker network rm food-network
```

## Production considerations
- Uses `node:20-alpine`.
- Installs production dependencies with `npm ci --omit=dev`.
- Excludes local dependencies, Git metadata, and environment files through `.dockerignore`.
- Runs as the non-root `node` user.
- Reads `PORT` and `NODE_ENV` from environment variables.
- Includes an HTTP health endpoint and Docker `HEALTHCHECK`.
- Uses a restart policy and custom Docker network in the documented run command.
